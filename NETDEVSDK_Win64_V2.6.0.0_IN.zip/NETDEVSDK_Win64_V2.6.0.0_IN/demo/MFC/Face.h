#pragma once
#include "afxcmn.h"
#include "RealtimeMonitoring.h"
#include "LibraryManagerment.h"
#include "MonitoringTask.h"
#include "PersonAlarmRecord.h"
#include "PersonPassRecord.h"


// CFace �Ի���

class CFace : public CDialog
{
	DECLARE_DYNAMIC(CFace)

public:
	CFace(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CFace();

// �Ի�������
	enum { IDD = IDD_VCA_FACE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTcnSelchangeTabVca(NMHDR *pNMHDR, LRESULT *pResult);

private:
	CTabCtrl m_oTabFace;
	CMonitoringTask m_oMonitoringTask;
	CLibraryManagerment m_oFaceLibraryManagerment;
    CPersonAlarmRecord m_oPersonAlarmRecord;
    CPersonPassRecord m_oPersonPassRecord;

public:
	CRealtimeMonitoring m_oRealtimeMonitoring;

private:
	void TabWithUpdate(INT32 nTabIndex);
};
