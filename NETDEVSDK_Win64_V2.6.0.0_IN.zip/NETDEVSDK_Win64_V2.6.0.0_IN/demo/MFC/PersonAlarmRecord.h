#pragma once


// CPersonAlarmRecord �Ի���

class CPersonAlarmRecord : public CDialog
{
	DECLARE_DYNAMIC(CPersonAlarmRecord)

public:
	CPersonAlarmRecord(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPersonAlarmRecord();

// �Ի�������
	enum { IDD = IDD_PERSON_ALARM_RECORD };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
    virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

    VOID InitDialog();
    VOID InitPersonDisPlayList();

    BOOL getTimeInfo(INT64& dwBeginTime, INT64& dwEndTime);
    long GetTick(const CString& strTime);
    VOID SavePicture(CString pszFileName, CHAR *pszBuf, INT32 dwSize);
    VOID CleanFaceRecordSnapshotInfoVector();
    VOID DisPlayFaceRecordSnapshotInfoVector();
    VOID FindPersonAlarmInfo();

private:
    CComboBox m_oCBoxMonitoType;
    CDateTimeCtrl m_oBeginDate;
    CDateTimeCtrl m_oBeginTime;
    CDateTimeCtrl m_oEndDate;
    CDateTimeCtrl m_oEndTime;
    CString m_strPersonName;
    CString m_strIDNumber;
    INT32 m_dwGender;
    CString m_strAlarmSource;
    CListCtrl m_oPersonInfoDisPlayList;
    CString m_strTotalNumber;
    CString m_strCurrentNumber;

    INT32 m_dwTotalNumber;
    INT32 m_dwCurrentNumber;
    std::vector<NETDEV_FACE_RECORD_SNAPSHOT_INFO_S> m_oFaceRecordSnapshotInfoVector;
public:
    afx_msg void OnBnClickedButtonPersonFind();
    afx_msg void OnBnClickedButtonPersonAlarmPrev();
    afx_msg void OnBnClickedButtonPersonAlarmNext();
};
