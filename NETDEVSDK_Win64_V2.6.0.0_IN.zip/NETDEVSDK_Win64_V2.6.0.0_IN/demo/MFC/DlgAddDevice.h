#pragma once
#include "afxwin.h"

class CDlgAddDevice : public CDialog
{
    DECLARE_DYNAMIC(CDlgAddDevice)

public:
    CDlgAddDevice(CWnd* pParent = NULL);
    virtual ~CDlgAddDevice();

    enum { IDD = IDD_DLG_ADD_DEVICE };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);
    virtual BOOL OnInitDialog();
    DECLARE_MESSAGE_MAP()

private:
    void InitCombo();

private:
    CString m_strIP;
    INT32 m_dwPort;
    CString m_strUsername;
    CString m_strPassword;

public:
    afx_msg void OnBnClickedAddDevice();
    afx_msg void OnBnClickedCancel();
    CComboBox m_oDeviceType;
    INT32 m_udwDeviceType;
};
