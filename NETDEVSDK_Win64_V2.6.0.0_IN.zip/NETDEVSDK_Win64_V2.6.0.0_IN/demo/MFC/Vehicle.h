#pragma once
#include "afxcmn.h"
#include "RealtimeMonitoring.h"
#include "LibraryManagerment.h"
#include "MonitoringTask.h"
#include "VehicleAlarmRecord.h"
#include "VehiclePassRecord.h"

// CVehicle �Ի���

class CVehicle : public CDialog
{
	DECLARE_DYNAMIC(CVehicle)

public:
	CVehicle(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CVehicle();

// �Ի�������
	enum { IDD = IDD_VCA_VEHICLE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
private:
	CTabCtrl m_oTabVehicle;
	CMonitoringTask m_oMonitoringTask;
	CLibraryManagerment m_oLibraryManagerment;
    CVehicleAlarmRecord m_oVehicleAlarmRecord;
    CVehiclePassRecord m_oVehiclePassRecord;

public:
	CRealtimeMonitoring m_oRealtimeMonitoring;

private:
	void TabWithUpdate(INT32 nTabIndex);
public:
	afx_msg void OnTcnSelchangeTabVehicle(NMHDR *pNMHDR, LRESULT *pResult);
};
