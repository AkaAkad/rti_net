#pragma once
#include "afxwin.h"
#include "PictureShow.h"


// CRealtimeMonitoring �Ի���

class CRealtimeMonitoring : public CDialog
{
	DECLARE_DYNAMIC(CRealtimeMonitoring)

public:
	CRealtimeMonitoring(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CRealtimeMonitoring();

// �Ի�������
	enum { IDD = IDD_REALTIME_MONITORING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	void SetType(INT32 nType);

private:
	void InitCtrl();

private:
	INT32 m_nMathSubID;
	INT32 m_nRecogizeSubID;

public:
	INT32 m_nType; //0:��ʾ������1����ʾ����
	CPictureShow m_oMatchPic;
	CPictureShow m_oRecogizePic;
	CString m_strMathInfo;
	CString m_strRecogizeInfo;

public:
	afx_msg void OnBnClickedBtnPersonMatchStart();
	afx_msg void OnBnClickedBtnPersonMatchStop();
	afx_msg void OnBnClickedBtnPersonRecognizeStart();
	afx_msg void OnBnClickedBtnPersonRecognizeStop();
};
