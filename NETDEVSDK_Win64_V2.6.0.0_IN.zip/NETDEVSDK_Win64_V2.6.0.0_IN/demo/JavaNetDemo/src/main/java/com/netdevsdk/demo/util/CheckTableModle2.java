package main.java.com.netdevsdk.demo.util;

import java.util.Vector;

import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

public class CheckTableModle2 extends DefaultTableModel{

	private static Vector data;
	private static Vector columnNames;
	
	
	public   CheckTableModle2(Vector data,Vector columnNames) {
		this.data=data;
		this.columnNames=columnNames;
	}

	// * 根据类型返回显示空间
   // * 布尔类型返回显示checkbox
    @SuppressWarnings("unchecked")
	public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }

    public void selectAllOrNull(boolean value) {
        for (int i = 0; i < getRowCount(); i++) {
            this.setValueAt(value, i, 0);
        }
    }


}
