package main.java.com.netdevsdk.demo.util;

import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_ALARM_SUBTYPE_E;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_ALARM_TYPE_E;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_CHN_PERMISSION_TYPE_E;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_FIND_ALARM_TYPE_E;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_LOG_MAIN_TYPE_E;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_LOG_SUB_TYPE_E;

public class Util {
	public static String getSubType(int type) {
		String subType=null;
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_SUB_TYPE_NOT_CONFIGURED) {
			subType="SubTypeNotConfigured";
		}else      
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DEV_TYPE_BASE) {
			subType="TypeBase";
		}else                     
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DEV_TROUBLE) {
			subType="Trouble";
		}else                         
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DEV_ALARM_EMERGENCY) {
			subType="AlarmEmergency";
		}else                
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BASE) {
			subType="EventBase";
		}else                    
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FIRE_ALARM) {
			subType="EventFireAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEYPADFIRE) {
			subType="EventKeypadfire";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEYPADEMERGENCY) {
			subType="EventKeypademergency";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEYPADMEDICAL) {
			subType="EventKeypadmedical";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DURESSCODEUSED) {
			subType="EventDuresscodeused";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_UNAUTHORIZEDENTRY) {
			subType="EventUnauthorizedentry";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BURGLARPOINTALARM) {
			subType="EventBurglarpointalarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SUPERVISORY) {
			subType="EventSupervisory";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FIRETROUBLE) {
			subType="EventFiretrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FIREPOINTTROUBLE) {
			subType="EventFirepointtrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BURGLARPOINTTROUBLE) {
			subType="EventBurglarpointtrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CANCELALARM) {
			subType="EventCancelalarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DISARM) {
			subType="EventDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ARM) {
			subType="EventArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FORCEDBYPASS) {
			subType="EventForcedbypass";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BYPASS) {
			subType="EventBypass";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_POINTRESTORAL) {
			subType="EventPointrestoral";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FAILTOCLOSE) {
			subType="EventFailtoclose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FAILTOOPEN) {
			subType="EventFailtoopen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HISTORYBUFFERDUMP) {
			subType="EventHistorybufferdump";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TESTMSG) {
			subType="EventTestmsg";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONETROUBLE) {
			subType="EventZonetrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONETROUBLERESTORE) {
			subType="EventZonetroublerestore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONESHORT) {
			subType="";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONEOPEN) {
			subType="EventZoneshort";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONENORMAL) {
			subType="EventZonenormal";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEVCLOSE) {
			subType="EventMxdevclose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEVOPEN) {
			subType="EventMxdevopen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEV1ZONEALARM) {
			subType="EventMxdev1ZoneAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEV2ZONEALARM) {
			subType="EventMxdev2ZoneAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEV3ZONEALARM) {
			subType="EventMxdev3ZoneAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEV1ZONERESTAORE) {
			subType="EventMxdev1ZoneRestaore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEV2ZONERESTAORE) {
			subType="EventMxdev2ZoneRestaore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MXDEV3ZONERESTAORE) {
			subType="EventMxdev3ZoneRestaore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_AC) {
			subType="EventTroubleAc";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_BATTERY) {
			subType="EventTroubleBattery";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_SNDREPORT) {
			subType="EventTroubleSndreport";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_CONTROL) {
			subType="EventTroubleControl";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_MXBUS) {
			subType="EventTroubleMxbus";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_RADIOSND) {
			subType="EventTroubleRadiosnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_ASSISTPOWER) {
			subType="EventTroubleAssistpower";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_OPTION) {
			subType="EventTroubleOption";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_LINK_BREAK) {
			subType="EventLinkBreak";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_LINK_RESUME) {
			subType="EventLinkResume";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_VOLTAGE_ALARM) {
			subType="EventVoltageAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_EXTERNDEV_TROUBLE) {
			subType="EventExterndevTrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_EXTERNDEV_RESUME) {
			subType="EventExterndevResume";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_POINT_DISARM) {
			subType="EventPointDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_POINT_ARM) {
			subType="EventPointArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FORCE_OPEN) {
			subType="EventForceOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BYPASS_FAILED) {
			subType="EventBypassFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_RESET_FAILED) {
			subType="";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_POINT_FIRETROUBLE) {
			subType="EventResetFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_POINT_SEPARATE) {
			subType="EventPointSeparate";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_POINT_ACTION) {
			subType="EventPointAction";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_POINT_RESUME) {
			subType="EventPointResume";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ROB_ACTION) {
			subType="EventRobAction";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MISSED_ARM) {
			subType="EventMissedArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MISSED_DISARM) {
			subType="EventMissedDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_AUXILARY_RST) {
			subType="EventAuxilaryRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_AUXILARY) {
			subType="EventAuxilary";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BURGLARY_RST) {
			subType="EventBurglaryRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BURGLARY) {
			subType="EventBurglary";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BYPASS_RST) {
			subType="EventBypassRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CANCEL) {
			subType="EventCancel";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DUPLICATE) {
			subType="EventDuplicate";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DURESS_RST) {
			subType="EventDuressRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DURESS) {
			subType="EventDuress";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FIRE_RST) {
			subType="EventFireRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FIRE_TROUBLE) {
			subType="EventFireTrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FIRE_TRB_RST) {
			subType="EventFireTrbRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MED_RST) {
			subType="EventMedRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PANIC) {
			subType="EventPanic";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PANIC_RST) {
			subType="EventPanicRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_RESET) {
			subType="EventReset";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_RELAY_SHORTED) {
			subType="EventRelayShorted";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_RELAY_RST) {
			subType="EventRelayRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_RELAY_TROUBLE) {
			subType="EventRelayTrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TAMPER) {
			subType="EventTamper";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TAMPER_RST) {
			subType="EventTamperRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE) {
			subType="EventTrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_RST) {
			subType="EventTroubleRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DFE_REMOTE_CONTROL) {
			subType="EventDfeRemoteControl";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DFE_SYNC) {
			subType="EventDfeSync";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DFE_LIFTING) {
			subType="EventDfeLifting";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DFE_SWITCH_NORMAL) {
			subType="EventDfeSwitchNormal";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DFE_SWITCH_ACCIDENT) {
			subType="EventDfeSwitchAccident";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DFE_KINFE_GATE) {
			subType="EventDfeKinfeGate";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ESCAPE) {
			subType="EventEscape";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ESCAPE_END) {
			subType="EventEscapeEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_VIOLENCE) {
			subType="EventViolence";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_VIOLENCE_END) {
			subType="EventViolenceEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ATTACKED) {
			subType="EventAttacked";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ATTACKED_END) {
			subType="EventAttackedEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_NATURAL_DISASTER) {
			subType="EventNaturalDisaster";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_NATURAL_DISASTER_END) {
			subType="EventNaturalDisasterEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ONE_KEY_ALARM) {
			subType="EventOneKeyAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ONE_KEY_ALARM_END) {
			subType="EventOneKeyAlarmEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CERC_NORMAL) {
			subType="EventCercNormal";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CERC_TOUCH) {
			subType="EventCercTouch";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CERC_BREAK) {
			subType="EventCercBreak";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CERC_SHORT) {
			subType="EventCercShort";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CERC_COMMU_ERR) {
			subType="EventCercCommuErr";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HYPERSEE_DDR_ALARM) {
			subType="EventHyperseeDdrAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HYPERSEE_DDR_ALARM_RST) {
			subType="EventHyperseeDdrAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HYPERSEE_IR_ALARM) {
			subType="EventHyperseeIrAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HYPERSEE_IR_ALARM_RST) {
			subType="EventHyperseeIrAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_UBI_ALARM) {
			subType="EventUbiAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HXTECH_CABLE_ALARM) {
			subType="EventHxtechCableAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DEVICE_UNDER_VOLTAGE_RST) {
			subType="EventDeviceUnderVoltageRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_NOT_READY) {
			subType="EventZoneNotReady";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_NOT_READY_RST) {
			subType="EventZoneNotReadyRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TELEPHONE_CABLE_FAULT) {
			subType="EventTelephoneCableFault";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TELEPHONE_CABLE_FAULT_RST) {
			subType="EventTelephoneCableFaultRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_AC_POWER_FAULT) {
			subType="EventAcPowerFault";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_TOUCH) {
			subType="EventZoneTouch";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_TOUCH_RESTORE) {
			subType="EventZoneTouchRestore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CAPTIVE) {
			subType="EventCaptive";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CAPTIVE_RST) {
			subType="EventCaptiveRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_UNDERVOLTAGE) {
			subType="EventUndervoltage";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_UNDERVOLTAGE_RST) {
			subType="EventUndervoltageRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TROUBLE_BATTERY_RST) {
			subType="EventTroubleBatteryRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DEV_POWER_REBOOT) {
			subType="EventDevPowerReboot";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TEST_FAILURE) {
			subType="EventTestFailure";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_OPERATOR_TOUCH_LONG) {
			subType="EventOperatorTouchLong";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_REMOTE_ARM) {
			subType="EventRemoteArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_REMOTE_DISARM) {
			subType="EventRemoteDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_REMOTE_STAY_ARM) {
			subType="EventRemoteStayArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_ARM) {
			subType="EventPwdArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_DISARM) {
			subType="EventPwdDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_STAY_DEV) {
			subType="EventPwdStayDev";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_ARM_PART) {
			subType="EventPwdArmPart";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_DISARM_PART) {
			subType="EventPwdDisarmPart";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_STAY_PART) {
			subType="EventPwdStayPart";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_ARM_ZONE) {
			subType="EventPwdArmZone";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_DISARM_ZONE) {
			subType="EventPwdDisarmZone";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_USER_ARM) {
			subType="EventUserArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_USER_DISARM) {
			subType="EventUserDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_USER_STAY_DEV) {
			subType="EventUserStayDev";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_USER_CLEAN_ALARM) {
			subType="EventUserCleanAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_PWD_OPEN_DOOR) {
			subType="EventPwdOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEY_OPEN_DOOR) {
			subType="EventKeyOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_REMOTE_OPEN_DOOR) {
			subType="EventRemoteOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_ARM) {
			subType="EventSwipeArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_DISARM) {
			subType="EventSwipeDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_LOCK) {
			subType="EventSwipeLock";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_UNLOCK) {
			subType="EventSwipeUnlock";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_RECORD) {
			subType="EventSwipeRecord";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_ATTENDANCE_IN) {
			subType="EventSwipeAttendanceIn";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_ATTENDANCE_OUT) {
			subType="EventSwipeAttendanceOut";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_TURNON_LIGHT) {
			subType="EventSwipeTurnonLight";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_OFF_LIGHT) {
			subType="EventSwipeOffLight";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWIPE_CARD_NUM) {
			subType="EventSwipeCardNum";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MANUAL_OPEN) {
			subType="EventManualOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_OPEN_DOOR) {
			subType="EventZoneOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_DOOR_LONGTIME) {
			subType="EventZoneDoorLongtime";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_ARM) {
			subType="EventZoneArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_DISARM) {
			subType="EventZoneDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TIMER_ARM) {
			subType="EventTimerArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TIMER_DISARM) {
			subType="EventTimerDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CENTRAL_COMM_NORMAL) {
			subType="EventCentralCommNormal";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CENTRAL_HANDSHAKE_FAILED) {
			subType="EventCentralHandshakeFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CENTRAL_RESPONSE_FAILED) {
			subType="EventCentralResponseFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_USER_CONFIRMATION) {
			subType="EventUserConfirmation";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_USER_TIMEOUT) {
			subType="EventUserTimeout";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TELEP_RINGING) {
			subType="EventTelepRinging";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TELEP_ARM) {
			subType="EventTelepArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TELEP_STATUS_OFFLINE) {
			subType="EventTelepStatusOffline";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TELEP_STATUS_ONLINE) {
			subType="EventTelepStatusOnline";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MSG_SEND_SUCC) {
			subType="EventMsgSendSucc";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MSG_SEND_FAILED) {
			subType="EventMsgSendFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWITCH_CLOSE) {
			subType="EventSwitchClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SWITCH_OFF) {
			subType="EventSwitchOff";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TEMPER_CHANGE) {
			subType="EventTemperChange";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HUMIDITY_CHANGE) {
			subType="EventHumidityChange";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DEVID_WRONG) {
			subType="EventDevidWrong";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ELEC_HIGH_ARM) {
			subType="EventElecHighArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ELEC_LOW_ARM) {
			subType="EventElecLowArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ELEC_ALARM_RST) {
			subType="EventElecAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ELEC_DISARM) {
			subType="EventElecDisarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ELEC_ARM) {
			subType="EventElecArm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEY_ALARM_OVER) {
			subType="EventKeyAlarmOver";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEY_PROL_TYPE) {
			subType="EventKeyProlType";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MOD_DEV_ADDR) {
			subType="EventModDevAddr";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_FORWARD_CMD) {
			subType="EventForwardCmd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BASE_VALUE) {
			subType="EventBaseValue";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_IMMEDIATELY_DEFEND_ALARM) {
			subType="EventImmediatelyDefendAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_IMMEDIATELY_DEFEND_ALARM_RST) {
			subType="EventImmediatelyDefendAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALL_DAY_NO_VOICE_ALARM) {
			subType="EventAllDayNoVoiceAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALL_DAY_NO_VOICE_ALARM_RST) {
			subType="EventAllDayNoVoiceAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALL_DAY_VOICE_ALARM) {
			subType="EventAllDayVoiceAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALL_DAY_VOICE_ALARM_RST) {
			subType="EventAllDayVoiceAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BOARD_DEFEND_ALARM) {
			subType="EventBoardDefendAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BOARD_DEFEND_ALARM_RST) {
			subType="EventBoardDefendAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_INNER_DELAY_DEFEND_ALARM) {
			subType="EventInnerDelayDefendAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_INNER_DELAY_DEFEND_ALARM_RST) {
			subType="EventInnerDelayDefendAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DELAY_DEFEND_ALARM) {
			subType="EventDelayDefendAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DELAY_DEFEND_ALARM_RST) {
			subType="EventDelayDefendAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_EXPAND_MODEL_FAULT_ALARM) {
			subType="EventExpandModelFaultAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_EXPAND_MODEL_FAULT_ALARM_RST) {
			subType="EventExpandModelFaultAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_OUTER_DISARMED) {
			subType="EventOuterDisarmed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_OUTER_ARMED) {
			subType="EventOuterArmed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEY_DISARMED) {
			subType="EventKeyDisarmed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_KEY_ARMED) {
			subType="EventKeyArmed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_WIRELESS_NET_WORK_EXCEPTION) {
			subType="EventWirelessNetWorkException";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_WIRELESS_NET_WORK_EXCEPTION_RST) {
			subType="EventWirelessNetWorkExceptionRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_WIRED_NET_WORK_BREAK) {
			subType="EventWiredNetWorkBreak";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_WIRED_NET_WORK_BREAK_RST) {
			subType="EventWiredNetWorkBreakRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SOFT_DEFEND_URGENCY_ALARM) {
			subType="EventSoftDefendUrgencyAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ARMED_STAY) {
			subType="EventArmedStay";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_IMMEDIATELY_ARMED) {
			subType="EventImmediatelyArmed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SMOKE_ALARM) {
			subType="EventSmokeAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SMOKE_ALARM_END) {
			subType="EventSmokeAlarmEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_WATER_ALARM) {
			subType="EventWaterAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_WATER_ALARM_END) {
			subType="EventWaterAlarmEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_IO_ON) {
			subType="EventIoOn";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_IO_OFF) {
			subType="EventIoOff";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_TOUNCH_ALARM) {
			subType="EventTounchAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_INVADE_ALARM) {
			subType="EventInvadeAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_BROKEN_ALARM) {
			subType="EventBrokenAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HELP) {
			subType="EventHelp";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DESTROY) {
			subType="EventDestroy";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ACS) {
			subType="EventAcs";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_OTHERS) {
			subType="EventOthers";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_ALARM) {
			subType="EventZoneAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ZONE_ALARM_RST) {
			subType="EventZoneAlarmRst";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_GATO_ALARM_FENCE) {
			subType="EventGatoAlarmFence";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_GATO_ALARM_HOST) {
			subType="EventGatoAlarmHost";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_GATO_ALARM_ETCZONE) {
			subType="EventGatoAlarmEtczone";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_GATO_ALARM_OFFLINE) {
			subType="EventGatoAlarmOffline";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_GATO_ALARM_SWITCH1) {
			subType="EventGatoAlarmSwitch1";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_GATO_ALARM_SWITCH2) {
			subType="EventGatoAlarmSwitch2";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_STEAL) {
			subType="EventSteal";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_GAS) {
			subType="EventGas";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SAVE) {
			subType="EventSave";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_INVADE_TROUBLE) {
			subType="EventInvadeTrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_SYS_TROUBLE) {
			subType="EventSysTrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_OPTICAL_FIBER_TROUBLE) {
			subType="EventOpticalFiberTrouble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_MOTION_DETECTION) {
			subType="EventMotionDetection";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_CALL_REMOVE) {
			subType="EventCallRemove";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_NOISE) {
			subType="EventNoise";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DELAYED) {
			subType="EventDelayed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_INPUT_ONE) {
			subType="EventAlarmInputOne";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_INPUT_TWO) {
			subType="EventAlarmInputTwo";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_CALL_EMERGENCY) {
			subType="EventAlarmCallEmergency";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_CALL_CONSULTANT) {
			subType="EventAlarmCallConsultant";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DOOR_MAGNET_OPEN) {
			subType="EventDoorMagnetOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DOOR_MAGNET_CLOSE) {
			subType="EventDoorMagnetClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DOOR_LOCK_OPEN) {
			subType="EventDoorLockOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_DOOR_LOCK_CLOSE) {
			subType="EventDoorLockClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_PORT_ONE) {
			subType="EventAlarmPortOne";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_PORT_TWO) {
			subType="EventAlarmPortTwo";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_PORTEX) {
			subType="EventAlarmPortex";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_TUMULT) {
			subType="EventAlarmTumult";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_110) {
			subType="EventAlarm110";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_119) {
			subType="EventAlarm119";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_120) {
			subType="EventAlarm120";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_FINDERCONNECT_FAILED) {
			subType="EventAlarmFinderconnectFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_OUTAGE) {
			subType="EventAlarmOutage";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_DISASSEMBLE) {
			subType="EventAlarmDisassemble";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_CIRCUIT) {
			subType="EventAlarmCircuit";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_TOUCHNET) {
			subType="EventAlarmTouchnet";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_PREVENTCUT) {
			subType="EventAlarmPreventcut";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_COCKING) {
			subType="EventAlarmCocking";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_SLACK) {
			subType="EventAlarmSlack";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_ALARM_ZONE_FORBIDDEN) {
			subType="EventAlarmZoneForbidden";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HIGH_TEMP) {
			subType="EventHighTemp";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_LOW_TEMP) {
			subType="EventLowTemp";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_HIGH_HUMI) {
			subType="EventHighHumi";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_EVENT_LOW_HUMI) {
			subType="EventLowHumi";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_MONITOR_DEVICE_ONLINE) {
			subType="MonitorDeviceOnline";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_ALARM_MONITOR_DEVICE_OFFLINE) {
			subType="MonitorDeviceOffline";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_BASE) {
			subType="EventBase";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DISCONNECT) {
			subType="EventDisconnect";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_INFRARED_ALARM) {
			subType="EventInfraredAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ILLICIT_OPEN_DOOR) {
			subType="EventIllicitOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_COERCE_ALARM) {
			subType="EventCoerceAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_OPEN_TIMEOUT) {
			subType="EventOpenTimeout";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CLOSE_TIMEOUT) {
			subType="EventCloseTimeout";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ANOMALOUS_CARD) {
			subType="EventAnomalousCard";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_OPEN_DOOR) {
			subType="EventCardOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_REMOTE_OPEN_DOOR) {
			subType="EventRemoteOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_MANUAL_OPEN_DOOR) {
			subType="EventManualOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_EMERGENCY_START) {
			subType="EventEmergencyStart";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_EMERGENCY_STOP) {
			subType="EventEmergencyStop";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_OPEN_SUCCESS) {
			subType="EventOpenSuccess";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_OPEN_FAILED) {
			subType="EventOpenFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CLOSE) {
			subType="EventClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CLOSE_FAILED) {
			subType="EventCloseFailed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_NO_AUTH) {
			subType="EventCardNoAuth";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_NO_DATE_LIMIT) {
			subType="EventNoDateLimit";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_ILLEGAL) {
			subType="EventCardIllegal";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_FIREPORTECT_ALRAM) {
			subType="EventFireportectAlram";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CANCEL_FIREPORTECT) {
			subType="EventCancelFireportect";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PRYING_RESIST_ALRAM) {
			subType="EventPryingResistAlram";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_SUPERPASSWD_OPEN_DOOR) {
			subType="EventSuperpasswdOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_COERCECODE_IN) {
			subType="EventCoercecodeIn";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_STATUS_OPEN) {
			subType="EventDoorStatusOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_STATUS_CLOSE) {
			subType="EventDoorStatusClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_FORCED_OPEN) {
			subType="EventDoorForcedOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_KEEP_OPEN) {
			subType="EventDoorKeepOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LOCK_FAILURE) {
			subType="EventLockFailure";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LOST_STOLEN_CARD) {
			subType="EventLostStolenCard";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PASSWD_WRONG) {
			subType="EventPasswdWrong";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ALWAYS_CLOSED) {
			subType="EventAlwaysClosed";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_PASSWD_ENTER) {
			subType="EventCardPasswdEnter";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_PASSWD_WRONG) {
			subType="EventCardPasswdWrong";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_MORE_CARD_OPEN) {
			subType="EventMoreCardOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_FIRST_CARD_OPEN) {
			subType="EventFirstCardOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_OUT_DATE) {
			subType="EventCardOutDate";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_WATCH) {
			subType="EventCardWatch";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_REMOTE_CLOSE_DOOR) {
			subType="EventRemoteCloseDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_REMOTE_ALWAYS_OPEN) {
			subType="EventRemoteAlwaysOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_REMOTE_ALWAYS_CLOSE) {
			subType="EventRemoteAlwaysClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LEGAL_CARD_PASS) {
			subType="EventLegalCardPass";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_AND_PSW_PASS) {
			subType="EventCardAndPswPass";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_AND_PSW_FAIL) {
			subType="EventCardAndPswFail";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_AND_PSW_TIMEOUT) {
			subType="EventCardAndPswTimeout";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_AND_PSW_OVER_TIME) {
			subType="EventCardAndPswOverTime";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_INVALID_CARD) {
			subType="EventInvalidCard";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_BUTTON_PRESS) {
			subType="EventDoorButtonPress";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_BUTTON_RELEASE) {
			subType="EventDoorButtonRelease";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_READER_DESMANTLE_ALARM) {
			subType="EventCardReaderDesmantleAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_READER_DESMANTLE_RESUME) {
			subType="EventCardReaderDesmantleResume";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_MAGNET_OPEN) {
			subType="EventDoorMagnetOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_MAGNET_CLOSE) {
			subType="EventDoorMagnetClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_MAGNET_OPEN_ABNORMAL) {
			subType="EventDoorMagnetOpenAbnormal";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_MAGNET_OPEN_TIMEOUT) {
			subType="EventDoorMagnetOpenTimeout";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ANTI_SNEAK_FAIL) {
			subType="EventAntiSneakFail";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_INTERLOCK_DOOR_NOT_CLOSE) {
			subType="EventInterlockDoorNotClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_MULTI_VERIFY_SUCCESS) {
			subType="EventMultiVerifySuccess";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LEADER_CARD_OPEN_BEGIN) {
			subType="EventLeaderCardOpenBegin";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LEADER_CARD_OPEN_END) {
			subType="EventLeaderCardOpenEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ALWAYS_OPEN_BEGIN) {
			subType="EventAlwaysOpenBegin";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ALWAYS_OPEN_END) {
			subType="EventAlwaysOpenEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ALWAYS_CLOSE_BEGIN) {
			subType="EventAlwaysCloseBegin";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ALWAYS_CLOSE_END) {
			subType="EventAlwaysCloseEnd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_KEYPRESS_OPEN_DOOR) {
			subType="EventKeypressOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_COMMU_INTERRUPT) {
			subType="EventCommuInterrupt";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_COMMU_RESTORE) {
			subType="EventCommuRestore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LEGAL_CREDIT_CARD) {
			subType="EventLegalCreditCard";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LEGAL_USER_ID) {
			subType="EventLegalUserId";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_NO_REG) {
			subType="EventCardNoReg";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_UNAUTH) {
			subType="EventCardUnauth";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_DISABLED) {
			subType="EventCardDisabled";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_EXPIRED) {
			subType="EventCardExpired";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_INVALID_TIME) {
			subType="EventInvalidTime";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PSW_ERROR) {
			subType="EventPswError";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PROHIBITED) {
			subType="EventProhibited";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_REQ_CENTER_OPEN_DOOR) {
			subType="EventReqCenterOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LEGAL_CARD_OPEN_DOOR) {
			subType="EventLegalCardOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_SUPER_CARD_OPEN_DOOR) {
			subType="EventSuperCardOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CENTER_OPEN_DOOR) {
			subType="EventCenterOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LINK_OPEN_DOOR) {
			subType="EventLinkOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_FORCE_OPEN_DOOR) {
			subType="EventForceOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_IS_OPEN) {
			subType="EventDoorIsOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_IS_CLOSE) {
			subType="EventDoorIsClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_STRESS_ALARM) {
			subType="EventStressAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_TRAILING_ALARM) {
			subType="EventTrailingAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_LOCK) {
			subType="EventDoorLock";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LIFT_DOOR_LOCK) {
			subType="EventLiftDoorLock";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_NOT_CLOSE) {
			subType="EventDoorNotClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_NEED_PSW) {
			subType="EventNeedPsw";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_NEED_FINGERPRINT) {
			subType="EventNeedFingerprint";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_REQ_INTERCOM) {
			subType="EventReqIntercom";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_EMERGENCY) {
			subType="EventEmergency";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PATROL_LEGAL_CREDIT_CARD) {
			subType="EventPatrolLegalCreditCard";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PATROL_LEGAL_FINGERPRINT) {
			subType="EventPatrolLegalFingerprint";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PATROL_CARD_NOT_REG) {
			subType="";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_NOT_PATROL_CARD) {
			subType="EventPatrolCardNotReg";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_NORMAL_PATROL) {
			subType="EventNormalPatrol";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ADVANCE_PATROL) {
			subType="EventAdvancePatrol";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_TIMEOUT_PATROL) {
			subType="EventTimeoutPatrol";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_INVALID_PATROL) {
			subType="EventInvalidPatrol";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_NOT_PATROL) {
			subType="EventNotPatrol";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_TH_ALARM) {
			subType="EventThAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_TH_RESTORE) {
			subType="EventThRestore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_TH_RECORD) {
			subType="EventThRecord";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_SMOKE_ALARM) {
			subType="EventSmokeAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_SMOKE_RESTORE) {
			subType="EventSmokeRestore";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_SMOKE_RECORD) {
			subType="EventSmokeRecord";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PC_CONTROL) {
			subType="EventPcControl";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_LIMITED_CARD_NUM) {
			subType="EventLimitedCardNum";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_REASON_UNKNOWN) {
			subType="EventReasonUnknown";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CONTROLLER_ON) {
			subType="EventControllerOn";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CONTROLLER_RESERT) {
			subType="EventControllerResert";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_FORCE_CLOSE) {
			subType="EventDoorForceClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_OFFLINE) {
			subType="EventDoorOffline";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_FIRE) {
			subType="EventFire";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CALL_EMERGENCY) {
			subType="EventCallEmergency";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_PERSON_FACE_DOOR) {
			subType="PersonFaceDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_PERSON_INVALE_DOOR) {
			subType="PersonInvaleDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_FINGERPRINT_OPEN_DOOR) {
			subType="EventFingerprintOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ANTI_SUBMARINE) {
			subType="EventAntiSubmarine";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PRESS_MISTAKE) {
			subType="EventPressMistake";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_PF_PW_RF_OPEN_DOOR) {
			subType="EventPfPwRfOpenDoor";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_FORCED_OPEN_CLEARED) {
			subType="EventDoorForcedOpenCleared";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_BLACKLIST) {
			subType="EventBlacklist";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_FAILED_SEND_CMD) {
			subType="EventFailedSendCmd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_FAILED_OPEN_DOOE_MU_CARD) {
			subType="EventFailedOpenDooeMuCard";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_INVALID_PERIOD) {
			subType="EventCardInvalidPeriod";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_CARD_REPORT_LOST) {
			subType="EventCardReportLost";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_TAMPER_ALARM) {
			subType="EventTamperAlarm";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_SWIPE_CARD_WHEN_NORMAL_OPEN) {
			subType="EventSwipeCardWhenNormalOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_OPEN_DOOR_BY_EMERGENCY_PWD) {
			subType="EventOpenDoorByEmergencyPwd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_OPEN_DOOR_WHEN_NORMAL_OPEN) {
			subType="EventOpenDoorWhenNormalOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_EXIT_BUTTON_DURING_ILLEGAL_PERIOD) {
			subType="EventExitButtonDuringIllegalPeriod";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_ALREADY_OPEN) {
			subType="EventDoorAlreadyOpen";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_DOOR_ALREADY_CLOSE) {
			subType="EventDoorAlreadyClose";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_ILLEGAL_PERIOD) {
			subType="EventIllegalPeriod";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_OPEN_DOOR_BY_DURESS_PWD) {
			subType="EventOpenDoorByDuressPwd";
		}else
		if(type==NETDEV_ALARM_SUBTYPE_E.NETDEV_DOOR_EVENT_END) {
			subType="EventEnd";
		}
		return subType;
	}
	
	
	
	
	public static String  getAlarmType(int AlarmType) {
		String message=null;
		if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MOVE_DETECT) {
			message="MoveDetect";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MOVE_DETECT_RECOVER) {
			message="MoveDetectRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VIDEO_LOST) {
			message="VideoLost";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VIDEO_LOST_RECOVER) {
			message="VideoLostRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VIDEO_TAMPER_DETECT) {
			message="VideoTamperDetect";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VIDEO_TAMPER_RECOVER) {
			message="VideoTamperRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_INPUT_SWITCH) {
			message="InputSwitch";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_INPUT_SWITCH_RECOVER) {
			message="InputSwitchRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_TEMPERATURE_HIGH) {
			message="TemperatureHigh";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_TEMPERATURE_LOW) {
			message="TemperatureLow";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_TEMPERATURE_RECOVER) {
			message="TemperatureRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_AUDIO_DETECT) {
			message="AudioDetect";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_AUDIO_DETECT_RECOVER) {
			message="AudioDetectRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SERVER_FAULT) {
			message="ServerFault";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SERVER_NORMAL) {
			message="ServerNormal";
		}
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REPORT_DEV_ONLINE) {
			message="ReportDevOnline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REPORT_DEV_OFFLINE) {
			message="ReportDevOffline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REPORT_DEV_REBOOT) {
			message="ReportDevReboot";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REPORT_DEV_SERVICE_REBOOT) {
			message="ReportDevServiceReboot";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REPORT_DEV_CHL_ONLINE) {
			message="ReportDevChlOnline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REPORT_DEV_CHL_OFFLINE) {
			message="ReportDevChlOffline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REPORT_DEV_DELETE_CHL) {
			message="ReportDevDeleteChl";
		}
		
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DEVICE_HIGHTEMP) {
			message="DeviceHightemp";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DEVICE_LOWTEMP) {
			message="DeviceLowtemp";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_LEDBOX_HIGHTEMP) {
			message="LedboxHightemp";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_LEDBOX_SMOKE) {
			message="LedboxSmoke";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DEVICE_HIGHTEMP_RECOVER) {
			message="DeviceHightempRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DEVICE_LOWTEMP_RECOVER) {
			message="DeviceLowtempRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FAN_FAULT_RECOVER) {
			message="FanFaultRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_LEDBOX_HIGHTEMP_RECOVER) {
			message="LedboxHightempRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_LEDBOX_SMOKE_RECOVER) {
			message="LedboxSmokeRecover";
		}
		
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_NET_FAILED) {
			message="NetFailed";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_NET_TIMEOUT) {
			message="NetTimeout";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SHAKE_FAILED) {
			message="ShakeFailed";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STREAMNUM_FULL) {
			message="StreamnumFull";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STREAM_THIRDSTOP) {
			message="StreamThirdstop";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FILE_END) {
			message="FileEnd";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_RTMP_CONNECT_FAIL) {
			message="RtmpConnectFail";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_RTMP_INIT_FAIL) {
			message="RtmpInitFail";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STREAM_DOWNLOAD_OVER) {
			message="StreamDownloadOver";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_PLAYBACK_FINISH) {
			message="PlaybackFinish";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VIDEO_RECORD_PART) {
			message="VideoRecordPart";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FISHEYE_STREAM_EXIST) {
			message="FisheyeStreamExist";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FISHEYE_STREAM_NOT_EXIST) {
			message="FisheyeStreamNotExist";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_PTZ_RESOUCE_FAIL) {
			message="PtzResouceFail";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_PTZ_STREAM_EXIST) {
			message="PtzStreamExist";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STREAM_NOT_EXIST) {
			message="StreamNotExist";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_INNER_TIMEOUT) {
			message="InnerTimeout";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STREAM_NOT_READY) {
			message="StreamNotReady";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_KEEP_ALIVE_FAILED) {
			message="KeepAliveFailed";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_OVER_ABILITY) {
			message="OverAbility";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_UNAUTHORIZED) {
			message="Unauthorized";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FORIBIDDEN) {
			message="Foribidden";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_METHOD_NOT_ALLOWED) {
			message="MethodNotAllowed";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_PRECONDITION_FAILED) {
			message="PreconditionFailed";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SESSION_NOT_FOUND) {
			message="SessionNotFound";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_NOT_ENOUGH_BANDWIDTH2) {
			message="NotEnoughBandwidth2";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REALPLAY_ESTABLISHED) {
			message="RealplayEstablished";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REALPLAY_RES_BUSY) {
			message="RealplayResBusy";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MULTICAST_DISABLED) {
			message="MulticastDisabled";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MULTICAST_PORT_OCCUPIED) {
			message="MulticastPortOccupied";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MULTICAST_PORT_EXHAUSTED) {
			message="MulticastPortExhausted";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MULTICAST_USER_NOT_EXIST) {
			message="MulticastUserNotExist";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_CHANNEL_NOT_ONLINE) {
			message="ChannelNotOnline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_TALKBACK_ENCODED_INVALID) {
			message="TalkbackEncodedInvalid";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VOICE_RES_USED_BY_TALKBACK) {
			message="VoiceResUsedByTalkback";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_TALKBACK_EXISTS) {
			message="TalkbackExists";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VOICE_WORK_NOT_EXIST) {
			message="VoiceWorkNotExist";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_TALKBACK_TIMEOUT) {
			message="TalkbackTimeout";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_TALKBACK_ERROR) {
			message="TalkbackError";
		}
		
		
		
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_ERROR) {
			message="DiskError";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_DISK_ERROR) {
			message="SysDiskError";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_ONLINE) {
			message="DiskOnline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_DISK_ONLINE) {
			message="SysDiskOnline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_OFFLINE) {
			message="DiskOffline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_DISK_OFFLINE) {
			message="SysDiskOffline";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_ABNORMAL_RECOVER) {
			message="DiskAbnormalRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_STORAGE_WILL_FULL) {
			message="DiskStorageWillFull";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_STORAGE_WILL_FULL_RECOVER) {
			message="DiskStorageWillFullRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_STORAGE_IS_FULL) {
			message="DiskStorageIsFull";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_DISK_STORAGE_IS_FULL) {
			message="SysDiskStorageIsFull";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_STORAGE_IS_FULL_RECOVER) {
			message="DiskStorageIsFullRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_RAID_DISABLED_RECOVER) {
			message="DiskRaidDisabledRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_RAID_DEGRADED) {
			message="DiskRaidDegraded";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_DISK_RAID_DEGRADED) {
			message="SysDiskRaidDegraded";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_RAID_DISABLED) {
			message="DiskRaidDisabled";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_DISK_RAID_DISABLED) {
			message="SysDiskRaidDisabled";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_RAID_DEGRADED_RECOVER) {
			message="DiskRaidDegradedRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STOR_GO_FULL) {
			message="StorGoFull";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_STOR_GO_FULL) {
			message="SysStorGoFull";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_ARRAY_NORMAL) {
			message="ArrayNormal";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_ARRAY_NORMAL) {
			message="SysArrayNormal";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DISK_RAID_RECOVERED) {
			message="DiskRaidRecovered";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STOR_ERR) {
			message="StorErr";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_STOR_ERR) {
			message="SysStorErr";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STOR_ERR_RECOVER) {
			message="StorErrRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STOR_DISOBEY_PLAN) {
			message="StorDisobeyPlan";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_STOR_DISOBEY_PLAN_RECOVER) {
			message="StorDisobeyPlanRecover";
		}
		
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_BANDWITH_CHANGE) {
			message="BandwithChange";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VIDEOENCODER_CHANGE) {
			message="VideoencoderChange";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_IP_CONFLICT) {
			message="IpConflict";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_IP_CONFLICT_CLEARED) {
			message="IpConflictCleared";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_NET_OFF) {
			message="NetOff";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_NET_RESUME_ON) {
			message="NetResumeOn";
		}
		
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALRAM_CONFLAG_DETECT) {
			message="ConflagDetect";
		}
		
		
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_ILLEGAL_ACCESS) {
			message="IllegalAccess";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SYS_ILLEGAL_ACCESS) {
			message="SysIllegalAccess";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_LINE_CROSS) {
			message="LineCross";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_OBJECTS_INSIDE) {
			message="ObjectsInside";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FACE_RECOGNIZE) {
			message="FaceRecognize";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_IMAGE_BLURRY) {
			message="ImageBlurry";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SCENE_CHANGE) {
			message="SceneChange";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_TRACK) {
			message="SmartTrack";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_LOITERING_DETECTOR) {
			message="LoiteringDetector";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_BANDWIDTH_CHANGE) {
			message="BandwidthChange";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_ALLTIME_FLAG_END) {
			message="AlltimeFlagEnd";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MEDIA_CONFIG_CHANGE) {
			message="MediaConfigChange";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_REMAIN_ARTICLE) {
			message="RemainArticle";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_PEOPLE_GATHER) {
			message="PeopleGather";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_ENTER_AREA) {
			message="EnterArea";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_LEAVE_AREA) {
			message="LeaveArea";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_ARTICLE_MOVE) {
			message="ArticleMove";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_FACE_MATCH_LIST) {
			message="SmartFaceMatchList";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_FACE_MATCH_LIST_RECOVER) {
			message="SmartFaceMatchListRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_FACE_MISMATCH_LIST) {
			message="SmartFaceMismatchList";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_FACE_MISMATCH_LIST_RECOVER) {
			message="SmartFaceMismatchListRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_VEHICLE_MATCH_LIST) {
			message="SmartVehicleMatchList";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_VEHICLE_MATCH_LIST_RECOVER) {
			message="SmartVehicleMatchListRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_VEHICLE_MISMATCH_LIST) {
			message="SmartVehicleMismatchList";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_VEHICLE_MISMATCH_LIST_RECOVER) {
			message="SmartVehicleMismatchListRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_IMAGE_BLURRY_RECOVER) {
			message="ImageBlurryRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_TRACK_RECOVER) {
			message="SmartTrackRecover";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_READ_ERROR_RATE) {
			message="SmartReadErrorRate";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_SPIN_UP_TIME) {
			message="SmartSpinUpTime";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_START_STOP_COUNT) {
			message="SmartStartStopCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_REALLOCATED_SECTOR_COUNT) {
			message="SmartReallocatedSectorCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_SEEK_ERROR_RATE) {
			message="SmartSeekErrorRate";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_POWER_ON_HOURS) {
			message="SmartPowerOnHours";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_SPIN_RETRY_COUNT) {
			message="SmartSpinRetryCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_CALIBRATION_RETRY_COUNT) {
			message="SmartCalibrationRetryCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_POWER_CYCLE_COUNT) {
			message="SmartPowerCycleCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_POWEROFF_RETRACT_COUNT) {
			message="SmartPoweroffRetractCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_LOAD_CYCLE_COUNT) {
			message="SmartLoadCycleCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_TEMPERATURE_CELSIUS) {
			message="SmartTemperatureCelsius";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_REALLOCATED_EVENT_COUNT) {
			message="SmartReallocatedEventCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_CURRENT_PENDING_SECTOR) {
			message="SmartCurrentPendingSector";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_OFFLINE_UNCORRECTABLE) {
			message="SmartOfflineUncorrectable";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_UDMA_CRC_ERROR_COUNT) {
			message="SmartUdmaCrcErrorCount";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_SMART_MULTI_ZONE_ERROR_RATE) {
			message="SmartMultiZoneErrorRate";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_RESOLUTION_CHANGE) {
			message="ResolutionChange";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_MANUAL) {
			message="Manual";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_ALARMHOST_COMMON) {
			message="AlarmhostCommon";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_DOORHOST_COMMON) {
			message="DoorhostCommon";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FACE_NOT_MATCH) {
			message="FaceNotMatch";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_FACE_MATCH_SUCCEED) {
			message="FaceMatchSucceed";
		}
		
		else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_VEHICLE_BLACK_LIST) {
			message="VehicleBlackList";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_HUMAN_SHAPE_DETECTION) {
			message="HumanShapeDetection";
		}else if(AlarmType==NETDEV_ALARM_TYPE_E.NETDEV_ALARM_HUMAN_SHAPE_DETECTION_RECOVER) {
			message="HumanShapeDetectionRecover";
		}
		return message;
	}
	
	
	
	public static String getFindAlarmType(int findAlarmType) {
		String message=null;
		if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_DISK_STORAGE_IS_FULL) {
			message="StorageIsFull";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_DISK_STORAGE_WILL_FULL) {
			message="StorageWillFull";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_STOR_ERR) {
			message="StorError";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_STOR_ERR_RECOVER) {
			message="StorErrorRecover";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_MOVE_DETECT) {
			message="MoveDetect";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_MOVE_DETECT_RECOVER) {
			message="MoveDetectRecover";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_VIDEO_TAMPER_DETECT) {
			message="VideoTamperDetect";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_VIDEO_TAMPER_RECOVER) {
			message="VideoTamperRecover";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_INPUT_SWITCH) {
			message="InputSwitch";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_INPUT_SWITCH_RECOVER) {
			message="InputSwitchRecover";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_BAND_CHANGE) {
			message="BandChange";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_IMAGE_BLURRY) {
			message="ImageBlurry";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_IMAGE_BLURRY_RECOVER) {
			message="ImageBlurryRecover";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_SCENE_CHANGE) {
			message="SceneChange";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_ILLEGAL_ACCESS) {
			message="IllegalAccess";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_REPORT_DEV_ONLINE) {
			message="ReportDevOnline";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_REPORT_DEV_OFFLINE) {
			message="ReportDevOffline";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_REPORT_DEV_VIDEO_LOSS) {
			message="ReportDevVideoLoss";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_REPORT_DEV_VIDEO_LOSS_RECOVER) {
			message="ReportDevVideoLossRecover";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_COUNT_PEOPLE) {
			message="CountPeople";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_HEAT_MAP) {
			message="HeatMap";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_LINE_DETECTOR) {
			message="LineDetector";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_CELL_MOTION) {
			message="CellMotion";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_LINE_CROSS) {
			message="LineCross";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_OBJECTS_INSIDE) {
			message="ObjectsInside";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_ACCESSZONE) {
			message="AccssZone";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_LEAVE_ZONE) {
			message="LeaveZone";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_HOVER_ZONE) {
			message="HoverZone";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_OVER_ZONE) {
			message="OverZone";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_CARE_ARTICLE) {
			message="CareArticle";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_REMAIN_ARTICLE) {
			message="RemainArticle";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_FACE_DETECTOR) {
			message="FaceDetector";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_GATHER) {
			message="Gather";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_GATHER_RECOVER) {
			message="GatherRecover";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_FAST_MOVE) {
			message="FastMove";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_ILLEGAL_PARKED) {
			message="IllegalParked";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_HUMAN_SHAPE_ON) {
			message="HumanShapeOn";
		}else if(findAlarmType==NETDEV_FIND_ALARM_TYPE_E.NETDEV_FIND_ALARM_HUMAN_SHAPE_OFF) {
			message="HumanShapeOff";
		}
		return message;
	}
	
	
	
	
	public static String getLogMainType(int LogMainType) {
		String message=null;
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ALL) {
			message="All";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ALARM) {
					message="Alarm";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_EXCEPTION) {
					message="Exception";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_OPERATION) {
					message="Operation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_MESSAGE) {
					message="Message";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VMS_ALL) {
					message="VmsAll";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_LOGIN) {
					message="Login";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ORGANIZATION_CONFIG) {
					message="OrganizationConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_USER_CONFIG) {
					message="UserConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ROLE_CONFIG) {
					message="RoleConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DEVICE_CONFIG) {
					message="DeviceConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_CHANNE_LCONFIG) {
					message="ChanneLconfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_SERVER_CONFIG) {
					message="ServerConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PTZ_CONFIG) {
					message="PtzConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VIDEOWALL_CONFIG) {
					message="VideowallConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_EMAP_CONFIG) {
					message="EmapConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_SYSTEM_CONFIG) {
					message="SystemConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_SEQUENCE_PLAN_CONFIG) {
					message="SequencePlanConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_NETWORK_KEYPAD_CONFIG) {
					message="NetworkKeypadConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_SEQUENCE_RESOURCE_CONFIG) {
					message="SequenceResourceConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_HOT_SPOT_AND_ZONE_CONFIG) {
					message="HotSpotAndZoneConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_USER_TIME_TEMPLATE_CONFIG) {
					message="UserTimeTemplateConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_SERVER_WORK_MODE) {
					message="ServerWorkMode";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PERMISSION_TIME_TEMPLATE_CONFIG) {
					message="PermissionTimeTemplateConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_TIME_CONFIG) {
					message="TimeConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_TIMESYNC_CONFIG) {
					message="TimesyncConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_HOLIDAY_CONFIG) {
					message="HolidayConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_NTPTIME_CONFIG) {
					message="NtptimeConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DST_CONFIG) {
					message="DstConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_RESRELATION_CONFIG) {
					message="ResrelationConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DEVICE_TIME_SYNC) {
					message="DeviceTimeSync";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_TCPIP_CONFIG) {
					message="TcpipConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_EZCLOUD_CONFIG) {
					message="EzcloudConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DDNS_CONFIG) {
					message="DdnsConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PORT_CONFIG) {
					message="PortConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PORTMAPPING_CONFIG) {
					message="PortmappingConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_EMAIL_CONFIG) {
					message="EmailConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_GBSERVER_CONFIG) {
					message="GbserverConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_GBT28181_LOCAL_CONFIG) {
					message="GBT28181LocalConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_UNP_CLIENT_CONFIG) {
					message="UnpClientConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_UNP_SERVER_CONFIG) {
					message="UnpServerConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_STATIC_ROUTE_CONFIG) {
					message="StaticRouteConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_802DOT1X_CONFIG) {
					message="802DOT1XConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ARP_CONFIG) {
					message="ArpConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_HTTPS_CONFIG) {
					message="HttpsConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_TELNET_CONFIG) {
					message="TelnetConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_SECURITY_PSW_CONFIG) {
					message="SecurityPswConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_IP_FILTER_RULE_CONFIG) {
					message="IpFilterRuleConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_MAINTENANCE_CONFIG) {
					message="MaintenanceConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_SET_MAX_LOG_RETENTION_TIME) {
					message="SetMaxLogRetentionTime";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_STREAM_TRANSMISSION_POLICY_CONFIG) {
					message="StreamTransmissionPolicyConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_BATCH_CONFIG) {
					message="BatchConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_RAIDMODE_CONFIG) {
					message="RaidmodeConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ARRAY_CONFIG) {
					message="ArrayConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DISK_MANAGEMENT_CONFIG) {
					message="DiskManagementConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_CHANNEL_SPACE_CONFIG) {
					message="ChannelSpaceConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_OVER_WRITE_POLICY_CONFIG) {
					message="OverWritePolicyConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DISKTEST_CONFIG) {
					message="DisktestConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_NET_DISK_CONFIG) {
					message="NetDiskConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_RECORDING_SCHEDULE_CONFIG) {
					message="RecordingScheduleConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_RECORDING_TIME_TEMPLATE_CONFIG) {
					message="RecordingTimeTemplateConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ALARM_CONFIG) {
					message="AlarmConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ALARM_TIMETEMPLATE_CONFIG) {
					message="AlarmTimetemplateConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_CONTACT_CONFIG) {
					message="ContactConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ALARM_TO_VIDEO_WALL_CONFIG) {
					message="AlarmToVideoWallConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VIDEO_WALL_SCENE_CONFIG) {
					message="VideoWallSceneConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VIDEO_WALL_WINDOW_CONFIG) {
					message="VideoWallWindowConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VIDEO_WALL_VIRTUALLED_CONFIG) {
					message="VideoWallVirtualledConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_EXTERNAL_ALARM_CONFIG) {
					message="ExternalAlarmConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DISK_GROUP_CONFIG) {
					message="DiskGroupConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_BK_PLAN_CONFIG) {
					message="BkPlanConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_BK_TASK_CONFIG) {
					message="BkTaskConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_LOCAL_BK_TASKCONFIG) {
					message="LocalBkTaskconfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_TVWALL_AUDIO_CONFIG) {
					message="TvwallAudioConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_LIVEVIEW) {
					message="Liveview";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PLAYBACK) {
					message="Playback";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_TWO_WAY_AUDIO) {
					message="TwoWayAudio";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PTZ) {
					message="Ptz";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DOWNLOAD) {
					message="Download";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_LIVEVIEW_ON_VIDEO_WALL) {
					message="LiveviewOnVideoWall";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PLAYBACK_ON_VIDEO_WALL) {
					message="PlaybackOnVideoWall";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_EMAP_OPERATION) {
					message="EmapOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_DC_SEQUENCE_OPERATION) {
					message="DcSequenceOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VIDEO_WALL_PLAYING_BY_NETWROK_KEYPAD) {
					message="VideoWallPlayingByNetwrokKeypad";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ALARM_TO_VIDEO_WALL) {
					message="AlarmToVideoWall";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ALARM_SUBSCRIPTION) {
					message="AlarmSubscription";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PRESET_PATROL_CONFIG) {
					message="PresetPatrolConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_AUTOGUARD_CONFIG) {
					message="AutoguardConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_RECORDED_PATROL_CONFIG) {
					message="RecordedPatrolConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ACCESS_CONTROL_PERSONNEL_MANAGEMENT) {
					message="AccessControlPersonnelManagement";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ACCESS_CONTROL_CARD_MANAGEMENT) {
					message="AccessControlCardManagement";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ZONE_OPERATION) {
					message="ZoneOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_ACCESS_CONTROL_DOOR) {
					message="AccessControlDoor";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_TRIGGER_ALARMOUTPUT) {
					message="TriggerAlarmoutput";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_CENTER_RECORD) {
					message="CenterRecord";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_FACE_LIBRARY_OPERATION) {
					message="FaceLibraryOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_FACE_MEMBER_OPERATION) {
					message="FaceMemberOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_FACE_CUSTOM_OPERATION) {
					message="FaceCustomOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_FACE_MEMBER_SORT_OPERATION) {
					message="FaceMemberSortOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_FACE_MONITORING_TASKO_PERATION) {
					message="FaceMonitoringTaskoPeration";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VEHICLE_LIBRARY_OPERATION) {
					message="VehicleLibraryOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VEHICLE_MEMBER_SORT_OPERATION) {
					message="VehicleMemberSortOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VEHICLE_MEMBER_OPERATION) {
					message="VehicleMemberOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_CAP_PAC_TASK) {
					message="CapPacTask";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_RECORD_BK_CONFIG) {
					message="RecordBkConfig";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_USB_OPERATION) {
					message="UsbOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_VEHICLE_MONITORING_TASK_OPERATION) {
					message="VehicleMonitoringTaskOperation";
		}else
		if(LogMainType==NETDEV_LOG_MAIN_TYPE_E.NETDEV_LOG_MAIN_TYPE_PERMISSION_ASSIGNMENT_OPERATION) {
					message="PermissionAssignmentOperation";
		}
		
		return message;
	}
	
	
	
	public static String getLogSubType(int logSubType) {
		String LogSubTypeMessage=null;
		if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALL_SUB_TYPES) {
			LogSubTypeMessage="AllSubTypes";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_MSG_HDD_INFO) {
			LogSubTypeMessage="MsgHddInfo";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_MSG_SMART_INFO) {
			LogSubTypeMessage="MsgSmartInfo";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_MSG_REC_OVERDUE) {
			LogSubTypeMessage="MsgRecOverdue";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_MSG_PIC_REC_OVERDUE) {
			LogSubTypeMessage="MsgPicRecOverdue";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_IPC_ONLINE) {
			LogSubTypeMessage="NoticeIpcOnline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_IPC_OFFLINE) {
			LogSubTypeMessage="NoticeIpcOffline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_ARRAY_RECOVER) {
			LogSubTypeMessage="NoticeArrayRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_INIT_ARRARY) {
			LogSubTypeMessage="NoticeInitArrary";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_REBUILD_ARRARY) {
			LogSubTypeMessage="NoticeRebuildArrary";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_POE_PORT_STATUS) {
			LogSubTypeMessage="NoticePoePortStatus";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_NETWORK_PORT_STATUS) {
			LogSubTypeMessage="NoticeNetworkPortStatus";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_NOTICE_DISK_ONLINE) {
			LogSubTypeMessage="NoticeDiskOnline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_MOTION_DETECT) {
			LogSubTypeMessage="AlarmMotionDetect";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_MOTION_DETECT_RESUME) {
			LogSubTypeMessage="AlarmMotionDetectResume";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_VIDEO_LOST) {
			LogSubTypeMessage="AlarmVideoLost";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_VIDEO_LOST_RESUME) {
			LogSubTypeMessage="AlarmVideoLostResume";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_VIDEO_TAMPER_DETECT) {
			LogSubTypeMessage="AlarmVideoTamperDetect";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_VIDEO_TAMPER_RESUME) {
			LogSubTypeMessage="AlarmVideoTamperResume";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_INPUT_SW) {
			LogSubTypeMessage="AlarmInputSw";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_INPUT_SW_RESUME) {
			LogSubTypeMessage="AlarmInputSwResume";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_IPC_ONLINE) {
			LogSubTypeMessage="AlarmIpcOnline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_IPC_OFFLINE) {
			LogSubTypeMessage="AlarmIpcOffline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_AUDIO_DETECTION_START) {
			LogSubTypeMessage="AlarmAudioDetectionStart";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_AUDIO_DETECTION_END) {
			LogSubTypeMessage="AlarmAudioDetectionEnd";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_CROSS_LINE_DETECT) {
			LogSubTypeMessage="AlarmCrossLineDetect";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_FACE_DETECT) {
			LogSubTypeMessage="AlarmFaceDetect";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_INTRUSION_DETECT) {
			LogSubTypeMessage="AlarmIntrusionDetect";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_POS) {
			LogSubTypeMessage="AlarmPos";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_IMAGETOOBLURRY_ON) {
			LogSubTypeMessage="AlarmImagetooblurryOn";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_IMAGETOOBLURRY_OFF) {
			LogSubTypeMessage="AlarmImagetooblurryOff";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_GLOBAL_SCENE_CHANGE) {
			LogSubTypeMessage="AlarmGlobalSceneChange";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_AUTO_TRACK_ON) {
			LogSubTypeMessage="AlarmAutoTrackOn";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_AUTO_TRACK_OFF) {
			LogSubTypeMessage="AlarmAutoTrackOff";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_CONFLAGRATION_ON) {
			LogSubTypeMessage="AlarmConflagrationOn";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_CONFLAGRATION_OFF) {
			LogSubTypeMessage="AlarmConflagrationOff";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_HUMAN_SHAPE_DETECT_ON) {
			LogSubTypeMessage="AlarmHumanShapeDetectOn";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_ALARM_HUMAN_SHAPE_DETECT_OFF) {
			LogSubTypeMessage="AlarmHumanShapeDetectOff";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_DISK_ONLINE) {
			LogSubTypeMessage="ExcepDiskOnline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_DISK_OFFLINE) {
			LogSubTypeMessage="ExcepDiskOffline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_DISK_ERR) {
			LogSubTypeMessage="ExcepDiskErr";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_STOR_ERR) {
			LogSubTypeMessage="ExcepStorErr";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_STOR_ERR_RECOVER) {
			LogSubTypeMessage="ExcepStorErrRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_STOR_DISOBEY_PLAN) {
			LogSubTypeMessage="ExcepStorDisobeyPlan";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_STOR_DISOBEY_PLAN_RECOVER) {
			LogSubTypeMessage="ExcepStorDisobeyPlanRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_ILLEGAL_ACCESS) {
			LogSubTypeMessage="ExcepIllegalAccess";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_IP_CONFLICT) {
			LogSubTypeMessage="ExcepIpConflict";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_NET_BROKEN) {
			LogSubTypeMessage="ExcepNetBroken";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_PIC_REC_ERR) {
			LogSubTypeMessage="ExcepPicRecErr";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_VIDEO_EXCEPTION) {
			LogSubTypeMessage="ExcepVideoException";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_VIDEO_MISMATCH) {
			LogSubTypeMessage="ExcepVideoMismatch";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_RESO_MISMATCH) {
			LogSubTypeMessage="ExcepResoMismatch";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_TEMP_EXCE) {
			LogSubTypeMessage="ExcepTempExce";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_RUNOUT_RECORD_SPACE) {
			LogSubTypeMessage="ExcepRunoutRecordSpace";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_RUNOUT_IMAGE_SPACE) {
			LogSubTypeMessage="ExcepRunoutImageSpace";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_OUT_RECORD_SPACE) {
			LogSubTypeMessage="ExcepOutRecordSpace";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_OUT_IMAGE_SPACE) {
			LogSubTypeMessage="ExcepOutImageSpace";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_ANRIDISASSEMBLY) {
			LogSubTypeMessage="ExcepAnridisassembly";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_ANRIDISASSEMBLY_RECOVER) {
			LogSubTypeMessage="ExcepAnridisassemblyRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_ARRAY_DAMAGE) {
			LogSubTypeMessage="ExcepArrayDamage";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_ARRAY_DEGRADE) {
			LogSubTypeMessage="ExcepArrayDegrade";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_RECORD_SNAPSHOT_ABNOR) {
			LogSubTypeMessage="ExcepRecordSnapshotAbnor";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_NET_BROKEN_RECOVER) {
			LogSubTypeMessage="ExcepNetBrokenRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_IP_CONFLICT_RECOVER) {
			LogSubTypeMessage="ExcepIpConflictRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_DEVICE_HIGHTEMP) {
			LogSubTypeMessage="ExcepDeviceHightemp";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_DEVICE_LOWTEMP) {
			LogSubTypeMessage="ExcepDeviceLowtemp";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_DEVICE_HIGHTEMP_RECOVER) {
			LogSubTypeMessage="ExcepDeviceHightempRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_DEVICE_LOWTEMP_RECOVER) {
			LogSubTypeMessage="ExcepDeviceLowtempRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_FAN_FAULT) {
			LogSubTypeMessage="ExcepFanFault";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_FAN_FAULT_RECOVER) {
			LogSubTypeMessage="ExcepFanFaultRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_LEDBOX_HIGHTEMP) {
			LogSubTypeMessage="ExcepLedboxHightemp";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_LEDBOX_HIGHTEMP_RECOVER) {
			LogSubTypeMessage="ExcepLedboxHightempRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_LEDBOX_SMOKE) {
			LogSubTypeMessage="ExcepLedboxSmoke";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_EXCEP_LEDBOX_SMOKE_RECOVER) {
			LogSubTypeMessage="ExcepLedboxSmokeRecover";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_LOGIN) {
			LogSubTypeMessage="OpsetLogin";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_LOGOUT) {
			LogSubTypeMessage="OpsetLogout";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_USER_ADD) {
			LogSubTypeMessage="OpsetUserAdd";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_USER_DEL) {
			LogSubTypeMessage="OpsetUserDel";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_USER_MODIFY) {
			LogSubTypeMessage="OpsetUserModify";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_START_REC) {
			LogSubTypeMessage="OpsetStartRec";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_STOP_REC) {
			LogSubTypeMessage="OpsetStopRec";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSETR_PLAY_DOWNLOAD) {
			LogSubTypeMessage="OpsetrPlayDownload";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DOWNLOAD) {
			LogSubTypeMessage="OpsetDownload";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PTZCTRL) {
			LogSubTypeMessage="OpsetPtzctrl";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PREVIEW) {
			LogSubTypeMessage="OpsetPreview";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_REC_TRACK_START) {
			LogSubTypeMessage="OpsetRecTrackStart";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_REC_TRACK_STOP) {
			LogSubTypeMessage="OpsetRecTrackStop";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_START_TALKBACK) {
			LogSubTypeMessage="OpsetStartTalkback";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_STOP_TALKBACK) {
			LogSubTypeMessage="OpsetStopTalkback";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_ADD) {
			LogSubTypeMessage="OpsetIpcAdd";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_DEL) {
			LogSubTypeMessage="OpsetIpcDel";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_SET) {
			LogSubTypeMessage="OpsetIpcSet";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_QUICK_ADD) {
			LogSubTypeMessage="OpsetIpcQuickAdd";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_ADD_BY_NETWORK) {
			LogSubTypeMessage="OpsetIpcAddByNetwork";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_MOD_IP) {
			LogSubTypeMessage="OpsetIpcModIp";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEV_BAS_CFG) {
			LogSubTypeMessage="OpsetDevBasCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_TIME_CFG) {
			LogSubTypeMessage="OpsetTimeCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SERIAL_CFG) {
			LogSubTypeMessage="OpsetSerialCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CHL_BAS_CFG) {
			LogSubTypeMessage="OpsetChlBasCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CHL_NAME_CFG) {
			LogSubTypeMessage="OpsetChlNameCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CHL_ENC_VIDEO) {
			LogSubTypeMessage="OpsetChlEncVideo";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CHL_DIS_VIDEO) {
			LogSubTypeMessage="OpsetChlDisVideo";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PTZ_CFG) {
			LogSubTypeMessage="OpsetPtzCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CRUISE_CFG) {
			LogSubTypeMessage="OpsetCruiseCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PRESET_CFG) {
			LogSubTypeMessage="OpsetPresetCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_VIDPLAN_CFG) {
			LogSubTypeMessage="OpsetVidplanCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MOTION_CFG) {
			LogSubTypeMessage="OpsetMotionCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_VIDLOSS_CFG) {
			LogSubTypeMessage="OpsetVidlossCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_COVER_CFG) {
			LogSubTypeMessage="OpsetCoverCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MASK_CFG) {
			LogSubTypeMessage="OpsetMaskCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SCREEN_OSD_CFG) {
			LogSubTypeMessage="OpsetScreenOsdCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ALARMIN_CFG) {
			LogSubTypeMessage="OpsetAlarminCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ALARMOUT_CFG) {
			LogSubTypeMessage="OpsetAlarmoutCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ALARMOUT_OPEN_MAN) {
			LogSubTypeMessage="OpsetAlarmoutOpenMan";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ALARMOUT_CLOSE_MAN) {
			LogSubTypeMessage="OpsetAlarmoutCloseMan";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ABNORMAL_CFG) {
			LogSubTypeMessage="OpsetAbnormalCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_HDD_CFG) {
			LogSubTypeMessage="OpsetHddCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_NET_IP_CFG) {
			LogSubTypeMessage="OpsetNetIpCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_NET_PPPOE_CFG) {
			LogSubTypeMessage="OpsetNetPppoeCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_NET_PORT_CFG) {
			LogSubTypeMessage="OpsetNetPortCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_NET_DDNS_CFG) {
			LogSubTypeMessage="OpsetNetDdnsCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_AUDIO_DETECT) {
			LogSubTypeMessage="OpsetAudioDetect";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SEARCH_EX_DISK) {
			LogSubTypeMessage="OpsetSearchExDisk";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ADD_EX_DISK) {
			LogSubTypeMessage="OpsetAddExDisk";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_EX_DISK) {
			LogSubTypeMessage="OpsetDelExDisk";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SET_EX_DISK) {
			LogSubTypeMessage="OpsetSetExDisk";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_LIVE_BY_MULTICAST) {
			LogSubTypeMessage="OpsetLiveByMulticast";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_BISC_DEV_INFO) {
			LogSubTypeMessage="OpsetBiscDevInfo";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PREVIEW_CFG) {
			LogSubTypeMessage="OpsetPreviewCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SET_EMAIL) {
			LogSubTypeMessage="OpsetSetEmail";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_TEST_EMAIL) {
			LogSubTypeMessage="OpsetTestEmail";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SET_IPCONTROL) {
			LogSubTypeMessage="OpsetSetIpcontrol";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PORT_MAP) {
			LogSubTypeMessage="OpsetPortMap";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ADD_TAG) {
			LogSubTypeMessage="OpsetAddTag";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_TAG) {
			LogSubTypeMessage="OpsetDelTag";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MOD_TAG) {
			LogSubTypeMessage="OpsetModTag";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_LOCK_RECORD) {
			LogSubTypeMessage="OpsetLockRecord";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_UNLOCK_RECORD) {
			LogSubTypeMessage="OpsetUnlockRecord";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DDNS_UPDATE_SUCCESS) {
			LogSubTypeMessage="OpsetDdnsUpdateSuccess";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DDNS_INCORRECT_ID) {
			LogSubTypeMessage="OpsetDdnsIncorrectId";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DDNS_DOMAIN_NAME_NOT_EXIST) {
			LogSubTypeMessage="OpsetDdnsDomainNameNotExist";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DDNS_UPDATE_FAIL) {
			LogSubTypeMessage="OpsetDdnsUpdateFail";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_HTTP_CFG) {
			LogSubTypeMessage="OpsetHttpCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IP_OFFLINE_ALARM_CFG) {
			LogSubTypeMessage="OpsetIpOfflineAlarmCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_TELNET_CFG) {
			LogSubTypeMessage="OpsetTelnetCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_TEST_DDNS_DOMAIN) {
			LogSubTypeMessage="OpsetTestDdnsDomain";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DDNS_DOMAIN_CONFLICT) {
			LogSubTypeMessage="OpsetDdnsDomainConflict";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DDNS_DOMAIN_INVALID) {
			LogSubTypeMessage="OpsetDdnsDomainInvalid";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_PRESET) {
			LogSubTypeMessage="OpsetDelPreset";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PTZ_3D_POSITION) {
			LogSubTypeMessage="OpsetPtz3DPosition";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SNAPSHOT_SCHEDULE_CFG) {
			LogSubTypeMessage="OpsetSnapshotScheduleCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IMAGE_UPLOAD_SCHEDULE_CFG) {
			LogSubTypeMessage="OpsetImageUploadScheduleCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_FTP_CFG) {
			LogSubTypeMessage="OpsetFtpCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_TEST_FTP_SERVER) {
			LogSubTypeMessage="OpsetTestFtpServer";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_START_MANUAL_SNAPSHOT) {
			LogSubTypeMessage="OpsetStartManualSnapshot";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CLOSE_MANUAL_SNAPSHOT) {
			LogSubTypeMessage="OpsetCloseManualSnapshot";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SNAPSHOT_CFG) {
			LogSubTypeMessage="OpsetSnapshotCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ADD_HOLIDAY) {
			LogSubTypeMessage="OpsetAddHoliday";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_HOLIDAY) {
			LogSubTypeMessage="OpsetDelHoliday";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MOD_HOLIDAY) {
			LogSubTypeMessage="OpsetModHoliday";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ONOFF_HOLIDAY) {
			LogSubTypeMessage="OpsetOnoffHoliday";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ALLOCATE_SPACE) {
			LogSubTypeMessage="OpsetAllocateSpace";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_HDD_FULL_POLICY_CFG) {
			LogSubTypeMessage="OpsetHddFullPolicyCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_AUDIO_STREAM_CFG) {
			LogSubTypeMessage="OpsetAudioStreamCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ARRAY_PROPERTY_CFG) {
			LogSubTypeMessage="OpsetArrayPropertyCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_HOT_SPACE_DISK_CFG) {
			LogSubTypeMessage="OpsetHotSpaceDiskCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CREAT_ARRAY) {
			LogSubTypeMessage="OpsetCreatArray";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ONE_CLICK_CREAT_ARRAY) {
			LogSubTypeMessage="OpsetOneClickCreatArray";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_REBUILD_ARRAY) {
			LogSubTypeMessage="OpsetRebuildArray";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_ARRAY) {
			LogSubTypeMessage="OpsetDelArray";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ENABLE_RAID) {
			LogSubTypeMessage="OpsetEnableRaid";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DISABLE_RAID) {
			LogSubTypeMessage="OpsetDisableRaid";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_TEST_SMART) {
			LogSubTypeMessage="OpsetTestSmart";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SMART_CFG) {
			LogSubTypeMessage="OpsetSmartCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_BAD_SECTOR_DETECT) {
			LogSubTypeMessage="OpsetBadSectorDetect";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_AUDIO_ALARM_DURATION) {
			LogSubTypeMessage="OpsetAudioAlarmDuration";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CLR_AUDIO_ALARM) {
			LogSubTypeMessage="OpsetClrAudioAlarm";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_TIME_SYNC_CFG) {
			LogSubTypeMessage="OpsetIpcTimeSyncCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ENABLE_DISK_GROUP) {
			LogSubTypeMessage="OpsetEnableDiskGroup";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DISABLE_DISK_GRRUOP) {
			LogSubTypeMessage="OpsetDisableDiskGrruop";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ONVIF_AUTH_CFG) {
			LogSubTypeMessage="OpsetOnvifAuthCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_8021X_CFG) {
			LogSubTypeMessage="Opset8021xCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ARP_PROTECTION_CFG) {
			LogSubTypeMessage="OpsetArpProtectionCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SMART_BASIC_INFO_CFG) {
			LogSubTypeMessage="OpsetSmartBasicInfoCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CROSS_LINE_DETECT_CFG) {
			LogSubTypeMessage="OpsetCrossLineDetectCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_INSTRUSION_DETECT_CFG) {
			LogSubTypeMessage="OpsetInstrusionDetectCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PEOPLE_COUNT_CFG) {
			LogSubTypeMessage="OpsetPeopleCountCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_FACE_DETECT_CFG) {
			LogSubTypeMessage="OpsetFaceDetectCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_FISHEYE_CFG) {
			LogSubTypeMessage="OpsetFisheyeCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CUSTOM_PROTOCOL_CFG) {
			LogSubTypeMessage="OpsetCustomProtocolCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_BEHAVIOR_SEARCH) {
			LogSubTypeMessage="OpsetBehaviorSearch";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_FACE_SEARCH) {
			LogSubTypeMessage="OpsetFaceSearch";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_PEOPLE_COUNT) {
			LogSubTypeMessage="OpsetPeopleCount";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_START_DVR) {
			LogSubTypeMessage="OpsetStartDvr";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_STOP_DVR) {
			LogSubTypeMessage="OpsetStopDvr";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_REBOOT_DVR) {
			LogSubTypeMessage="OpsetRebootDvr";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_UPGRADE) {
			LogSubTypeMessage="OpsetUpgrade";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_LOGFILE_EXPORT) {
			LogSubTypeMessage="OpsetLogfileExport";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CFGFILE_EXPORT) {
			LogSubTypeMessage="OpsetCfgfileExport";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CFGFILE_IMPORT) {
			LogSubTypeMessage="OpsetCfgfileImport";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CONF_SIMPLE_INIT) {
			LogSubTypeMessage="OpsetConfSimpleInit";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_CONF_ALL_INIT) {
			LogSubTypeMessage="OpsetConfAllInit";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_VCA_BACKUP) {
			LogSubTypeMessage="OpsetVcaBackup";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_3G4G_CFG) {
			LogSubTypeMessage="Opset3g4gCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MOUNT_EXTENDED_DISK) {
			LogSubTypeMessage="OpsetMountExtendedDisk";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_UNMOUNT_EXTENDED_DISK) {
			LogSubTypeMessage="OpsetUnmountExtendedDisk";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_FORCE_USER_OFFLINE) {
			LogSubTypeMessage="OpsetForceUserOffline";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_AUTO_FUNCTION) {
			LogSubTypeMessage="OpsetAutoFunction";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_IPC_UPRAGDE) {
			LogSubTypeMessage="OpsetIpcUpragde";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_RESTORE_IPC_DEFAULTS) {
			LogSubTypeMessage="OpsetRestoreIpcDefaults";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ADD_TRANSACTION) {
			LogSubTypeMessage="OpsetAddTransaction";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MOD_TRANSACTION) {
			LogSubTypeMessage="OpsetModTransaction";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_TRANSACTION) {
			LogSubTypeMessage="OpsetDelTransaction";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_POS_OSD) {
			LogSubTypeMessage="OpsetPosOsd";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_ADD_HOT_SPACE_DEV) {
			LogSubTypeMessage="OpsetAddHotSpaceDev";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_HOT_SPACE_DEV) {
			LogSubTypeMessage="OpsetDelHotSpaceDev";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MOD_HOT_SPACE_DEV) {
			LogSubTypeMessage="OpsetModHotSpaceDev";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEL_WORK_DEV) {
			LogSubTypeMessage="OpsetDelWorkDev";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_WORKMODE_TO_NORMAL_CFG) {
			LogSubTypeMessage="OpsetWorkmodeToNormalCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_WORKMODE_TO_HOTSPACE_CFG) {
			LogSubTypeMessage="OpsetWorkmodeToHotspaceCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_AUTO_GUARD_CFG) {
			LogSubTypeMessage="OpsetAutoGuardCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_MULTICAST_CFG) {
			LogSubTypeMessage="OpsetMulticastCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_DEFOCUS_DETECT_CFG) {
			LogSubTypeMessage="OpsetDefocusDetectCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SCENECHANGE_CFG) {
			LogSubTypeMessage="OpsetScenechangeCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_AUTO_TRCAK_CFG) {
			LogSubTypeMessage="OpsetAutoTrcakCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_SORT_CAMERA_CFG) {
			LogSubTypeMessage="OpsetSortCameraCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_OPSET_WATER_MARK_CFG) {
			LogSubTypeMessage="OpsetWaterMarkCfg";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_ALL) {
			LogSubTypeMessage="VmsOprerateSubAll";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_USER_LOGIN) {
			LogSubTypeMessage="VmsOprerateSubUserLogin";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_USER_LOGOUT) {
			LogSubTypeMessage="VmsOprerateSubUserLogout";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_USER_START_OPERATION) {
			LogSubTypeMessage="VmsOprerateSubUserStartOperation";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_USER_STOP_OPERATION) {
			LogSubTypeMessage="VmsOprerateSubUserStopOperation";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_NEW_CONFIG) {
			LogSubTypeMessage="VmsOprerateSubNewConfig";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_EDIT_CONFIG) {
			LogSubTypeMessage="VmsOprerateSubEditConfig";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_DELETE_CONFIG) {
			LogSubTypeMessage="VmsOprerateSubDeleteConfig";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_ENABLE_CONFIG) {
			LogSubTypeMessage="VmsOprerateSubEnableConfig";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_DISABLE_CONFIG) {
			LogSubTypeMessage="VmsOprerateSubDisableConfig";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_TEST_CONFIG) {
			LogSubTypeMessage="VmsOprerateSubTestConfig";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_OPEN_DOOR) {
			LogSubTypeMessage="VmsOprerateSubOpenDoor";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_CLOSE_DOOR) {
			LogSubTypeMessage="VmsOprerateSubCloseDoor";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_SARM) {
			LogSubTypeMessage="VmsOprerateSubSarm";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_DISARM) {
			LogSubTypeMessage="VmsOprerateSubDisarm";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_BYPASS) {
			LogSubTypeMessage="VmsOprerateSubBypass";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_UNBYPASS) {
			LogSubTypeMessage="VmsOprerateSubUnbypass";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_SHARE_DEVICE) {
			LogSubTypeMessage="VmsOprerateSubShareDevice";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_UN_SHARE_DEVICE) {
			LogSubTypeMessage="VmsOprerateSubUnShareDevice";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_START_CAP_PAC_TASK) {
			LogSubTypeMessage="VmsOprerateSubStartCapPacTask";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_STOP_CAP_PAC_TASK) {
			LogSubTypeMessage="VmsOprerateSubStopCapPacTask";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_DELETE_CAPPAC_TASK) {
			LogSubTypeMessage="VmsOprerateSubDeleteCappacTask";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_USB_INSERT) {
			LogSubTypeMessage="VmsOprerateSubUsbInsert";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_USB_PULL_OUT) {
			LogSubTypeMessage="VmsOprerateSubUsbPullOut";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_USB_FORMAT) {
			LogSubTypeMessage="VmsOprerateSubUsbFormat";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_SYNC_DEV_CHL_INFO) {
			LogSubTypeMessage="VmsOprerateSubSyncDevChlInfo";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_PLAYBACK_LOCK) {
			LogSubTypeMessage="VmsOprerateSubPlaybackLock";
		}else
       if(logSubType==NETDEV_LOG_SUB_TYPE_E.NETDEV_LOG_VMS_OPRERATE_SUB_PLAYBACK_UNLOCK) {
			LogSubTypeMessage="VmsOprerateSubPlaybackUnlock";
		}
		return LogSubTypeMessage;
	}
	
	
	
	public static String getAlarmRunMode(int mode) {
		String getAlarmRunMode=null;
		if(mode==1) {
			getAlarmRunMode="Open";
		}else if(mode==2){
			getAlarmRunMode="Closed";
		}
		return getAlarmRunMode;
	}
	
	
	
	
	
	public static String getEnable(int status) {
		String getEnableString=null;
		if(status==0) {
			getEnableString="Disabled";
		}else {
			getEnableString="Enable";
		}
		return getEnableString;
	}
}
