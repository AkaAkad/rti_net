package main.java.com.netdevsdk.demo.liveview.live;

import main.java.com.netdevsdk.demo.NetDemo;

import javax.swing.JOptionPane;

/**
 * 
 * @introduction  Make I frame
 * @description Support IPC/NVR/VMS
 */
public class MakeI {

    /**
     * 
     * @introduction Make I frame
     * @description Calling the interface of NETDEV_MakeKeyFrame to dynamically create an I frame
     *
     */
    public static void makeI(){
        if(null == NetDemo.lpUserID){
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        if(NetDemo.ChannelID == 0){
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        
        boolean bRet = NetDemo.netdevsdk.NETDEV_MakeKeyFrame(NetDemo.lpUserID, NetDemo.ChannelID, 0);
        if(bRet){
            JOptionPane.showMessageDialog(null, "Make Key Frame OK");
        }
        else{
            JOptionPane.showMessageDialog(null, "Make Key Frame failed,  Please check device status.");
        }
    }
}
