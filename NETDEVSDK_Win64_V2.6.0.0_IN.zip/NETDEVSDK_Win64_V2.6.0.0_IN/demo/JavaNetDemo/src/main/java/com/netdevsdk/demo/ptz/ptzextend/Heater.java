package main.java.com.netdevsdk.demo.ptz.ptzextend;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PTZ_E;

/**
 * 
 * @introduction Wiper Heater operation includes opening heater and closing heater
 * @description  
 */
public class Heater {
    
    /* Open the heater */
    public static void heaterOn() {
        ExtendOperation.Operation(NETDEV_PTZ_E.NETDEV_PTZ_HEATON);
    }
    
    /* Close the heater */
    public static void heaterOff() {
        ExtendOperation.Operation(NETDEV_PTZ_E.NETDEV_PTZ_HEATOFF);
    }

}
