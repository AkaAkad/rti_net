package main.java.com.netdevsdk.demo.ptz.ptzextend;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_PTZ_E;
/**
 * 
 * @introductionWiper Light operation includes opening light and closing light.
 * @description  
 */
public class Light {
    
    /* Open the light */
    public static void lightOn() {
        ExtendOperation.Operation(NETDEV_PTZ_E.NETDEV_PTZ_LIGHTON);
    }
    
    /* Close the light */
    public static void lightOff() {
        ExtendOperation.Operation( NETDEV_PTZ_E.NETDEV_PTZ_LIGHTOFF);
    }
}
