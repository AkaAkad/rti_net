package main.java.com.netdevsdk.demo.liveview.live;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;

public class Mute {
    /**
     * 
     * @introduction Set the mute state
     * @description Calling the interface of NETDEV_SetMuteStatus to set the mute state,
     * 0 represents mute and 1 represents non-mute
     *
     */
    public static void changeMuteStatus() {
        if(null == NetDemo.lpUserID){
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
        }
        /* Open talk intercom but close live preview */
        if(NetDemo.lpPlayHandle==null&&NetDemo.lpTalkHandle!=null){
            if(NetDemo.getMute2==0) {
                boolean bRet= NetDemo.netdevsdk.NETDEV_SetMuteStatus(NetDemo.lpTalkHandle,NetDemo.getMute2);
                if(bRet) {                   
                    boolean bRet1=NetDemo.netdevsdk.NETDEV_CloseSound(NetDemo.lpTalkHandle);
                    if(bRet1) {
                        JOptionPane.showMessageDialog(null, "Open the mute success");                      
                        NetDemo.getMute2=1;
                        NetDemo.jSliderLiveSound.setEnabled(false);
                    }else {
                        JOptionPane.showMessageDialog(null, "Open the mute failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                    }
                }else {
                    JOptionPane.showMessageDialog(null, "SetMuteStatus failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                    System.out.println("netdevsdk.NETDEV_SetMuteStatus failed" +NetDemo.netdevsdk.NETDEV_GetLastError());
                    return;
                }

            }
            else if(NetDemo.getMute2==1) {
                boolean bRet= NetDemo.netdevsdk.NETDEV_SetMuteStatus(NetDemo.lpTalkHandle,NetDemo.getMute2);
                if(bRet) {
                    boolean bRet1=NetDemo.netdevsdk.NETDEV_OpenSound(NetDemo.lpTalkHandle);
                    if(bRet1) {
                        JOptionPane.showMessageDialog(null, "Close the mute  success");
                        NetDemo.getMute2=0;
                        NetDemo.jSliderLiveSound.setValue(120);
                        NetDemo.jSliderLiveSound.setEnabled(true);
                    }else {
                        JOptionPane.showMessageDialog(null, "Close the mute failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                    }
                }else {
                    JOptionPane.showMessageDialog(null, "SetMuteStatus failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                    System.out.println("netdevsdk.NETDEV_SetMuteStatus failed" +NetDemo.netdevsdk.NETDEV_GetLastError());
                    return;
                }
            }
        }
        /* Open live preview and talk intercom */
        else if(NetDemo.lpPlayHandle!=null&&NetDemo.lpTalkHandle!=null) {
            if (NetDemo.getMute2 == 0) {
                boolean bRet = NetDemo.netdevsdk.NETDEV_SetMuteStatus(NetDemo.lpTalkHandle, NetDemo.getMute2);
                if (bRet) {
                        boolean bRet1 = NetDemo.netdevsdk.NETDEV_CloseSound(NetDemo.lpTalkHandle);
                        if (bRet1) {
                            JOptionPane.showMessageDialog(null, "Open the mute success");
                            NetDemo.getMute2 = 1;
                            NetDemo.jSliderLiveSound.setEnabled(false);
                        } else {
                            JOptionPane.showMessageDialog(null, "Open the mute failed,error code" + NetDemo.netdevsdk.NETDEV_GetLastError());
                        }

                } else {
                    JOptionPane.showMessageDialog(null, "Set MuteStatus failed,error code" + NetDemo.netdevsdk.NETDEV_GetLastError());
                    System.out.println("netdevsdk.NETDEV_SetMuteStatus failed" + NetDemo.netdevsdk.NETDEV_GetLastError());
                    return;
                }
            } else if (NetDemo.getMute2 == 1) {
                boolean bRet = NetDemo.netdevsdk.NETDEV_SetMuteStatus(NetDemo.lpTalkHandle, NetDemo.getMute2);
                if (bRet) {
                        boolean bRet1 = NetDemo.netdevsdk.NETDEV_OpenSound(NetDemo.lpTalkHandle);
                        if (bRet1) {
                            JOptionPane.showMessageDialog(null, "Close the mute success");
                            NetDemo.getMute2 = 0;
                            NetDemo.jSliderLiveSound.setValue(120);
                            NetDemo.jSliderLiveSound.setEnabled(true);
                            
                        } else {
                            JOptionPane.showMessageDialog(null, "Close the mute failed,error code" + NetDemo.netdevsdk.NETDEV_GetLastError());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Set MuteStatus failed,error code" + NetDemo.netdevsdk.NETDEV_GetLastError());
                        System.out.println("netdevsdk.NETDEV_SetMuteStatus failed" + NetDemo.netdevsdk.NETDEV_GetLastError());
                        return;
                    }
            }
            /* Open live preview but close talk intercom */
        }else if (NetDemo.lpPlayHandle != null &&NetDemo.lpTalkHandle == null) {
                if(NetDemo.getMute2==0) {
                    boolean bRet= NetDemo.netdevsdk.NETDEV_SetMuteStatus(NetDemo.lpPlayHandle,NetDemo.getMute2);
                    if(bRet) {
                        boolean bRet1=NetDemo.netdevsdk.NETDEV_CloseSound(NetDemo.lpPlayHandle);
                        if(bRet1) {
                            JOptionPane.showMessageDialog(null, "Open the mute success");
                            NetDemo.getMute2=1;
                            NetDemo.jSliderLiveSound.setEnabled(false);
                        }else {
                            JOptionPane.showMessageDialog(null, "Open the mute failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                        }
                    }else {
                        JOptionPane.showMessageDialog(null, "SetMuteStatus failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                        System.out.println("netdevsdk.NETDEV_SetMuteStatus failed" +NetDemo.netdevsdk.NETDEV_GetLastError());
                        return;
                    }

                }
                else if(NetDemo.getMute2==1) {
                    boolean bRet= NetDemo.netdevsdk.NETDEV_SetMuteStatus(NetDemo.lpPlayHandle,NetDemo.getMute2);
                    if(bRet) {
                        boolean bRet1=NetDemo.netdevsdk.NETDEV_OpenSound(NetDemo.lpPlayHandle);
                        if(bRet1) {
                            JOptionPane.showMessageDialog(null, "Close the mute success");
                            NetDemo.getMute2=0;
                            NetDemo.jSliderLiveSound.setValue(120);
                            NetDemo.jSliderLiveSound.setEnabled(true);
                        }else {
                            JOptionPane.showMessageDialog(null, "Close the mute failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                        }
                    }else {
                        JOptionPane.showMessageDialog(null, "SetMuteStatus failed,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
                        System.out.println("netdevsdk.NETDEV_SetMuteStatus failed" +NetDemo.netdevsdk.NETDEV_GetLastError());
                        return;
                    }
                }
            }
    }
}
