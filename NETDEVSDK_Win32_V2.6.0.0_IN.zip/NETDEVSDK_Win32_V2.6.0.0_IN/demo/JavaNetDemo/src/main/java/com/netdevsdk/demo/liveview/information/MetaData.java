package main.java.com.netdevsdk.demo.liveview.information;

import javax.swing.JOptionPane;

import main.java.com.netdevsdk.demo.NetDemo;
import main.java.com.netdevsdk.lib.NetDEVSDKLib.NETDEV_IVA_SHOW_RULE_E;

/**
 * 
 * @introduction IVA
 * @description Support IPC/NVR/VMS
 */
public class MetaData {

    /**
     * 
     * @introduction Set MetaData
     * @description Calling the interface of NETDEV_SetIVAShowParam 
     *
     */
	public static void setMetaData() {
	    if(null == NetDemo.lpUserID) {
            JOptionPane.showMessageDialog(null, "Please Login device first. error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
            return;
            }
        if(NetDemo.ChannelID == 0){
            JOptionPane.showMessageDialog(null, "Please select an online channel.");
            return;
        }
		int bEnableIVA=0;
		if(NetDemo.jCheckBoxVAEnable.isSelected()){
		    bEnableIVA = 1;
		}else {
		        JOptionPane.showMessageDialog(null, "Please first set enable");
		        return;
		}
	boolean bRet=NetDemo.netdevsdk.NETDEV_SetIVAEnable(NetDemo.lpPlayHandle,bEnableIVA);
    if(bRet) {
	    int numRow=NetDemo.VATable.getRowCount();
	    for(int i=0;i<numRow;i++) {
	        boolean checked=(boolean)NetDemo.VATable.getValueAt(i, 0);
	        int dwShowParam	=0;
	        String dwShowParamString=(String)NetDemo.VATable.getValueAt(i, 1);
	        if(checked) {
	            switch (dwShowParamString) {
                case "RULE":
                    dwShowParam = NETDEV_IVA_SHOW_RULE_E.NETDEV_IVA_SHOW_RULE;
                    break;
                case "TOUTH_RULE":
                    dwShowParam = NETDEV_IVA_SHOW_RULE_E.NETDEV_IVA_SHOW_RESULT_TOUTH_RULE;
                    break;
                case "UNTOUTH_RULE":
                    dwShowParam = NETDEV_IVA_SHOW_RULE_E.NETDEV_IVA_SHOW_RESULT_UNTOUTH_RULE;
                    break;
                case "TRACK":
                    dwShowParam = NETDEV_IVA_SHOW_RULE_E.NETDEV_IVA_SHOW_TRACK;
                    break;
	            }
	        }
	        NetDemo.getVAsum+=dwShowParam;
	    }
	    
	    boolean bRet2= NetDemo.netdevsdk.NETDEV_SetIVAShowParam(NetDemo.getVAsum);
	    NetDemo.getVAsum=0;
	    if(!bRet2) {
	        JOptionPane.showMessageDialog(null, "Set failed,please fist start live,if already,maybe not support,error code"+NetDemo.netdevsdk.NETDEV_GetLastError());
	        System.out.printf("NETDEV_SetIVAShowParam failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
	    }else {
	        JOptionPane.showMessageDialog(null,"Set success");
	    }
	}else {
	        JOptionPane.showMessageDialog(null, "Set failed,please fist start live,"+NetDemo.netdevsdk.NETDEV_GetLastError());
	        System.out.printf("NETDEV_SetIVAEnable failed:%d\n", NetDemo.netdevsdk.NETDEV_GetLastError());
	    }
    }
}
