#pragma once


// CPersonInfo �Ի���

class CPersonInfo : public CDialog
{
	DECLARE_DYNAMIC(CPersonInfo)

public:
	CPersonInfo(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPersonInfo();
    virtual BOOL OnInitDialog();

    VOID SetPersonLibID(INT32 dwPersonLibId);
    VOID SetType(INT32 dwType);
    VOID AddPerson();
    VOID ModifyPerson();
    VOID SetPersonInfo(LPNETDEV_PERSON_INFO_S pstPersomInfo);
    VOID InitIDType();
    INT32 ReadPictureFile(CString strFileName, CHAR* pszDst);
    VOID ReloadPersonInfo();
    VOID CleanCacheData();

    INT32 m_nType; //0:��ʾ���ӣ�1����ʾ�޸�

// �Ի�������
	enum { IDD = IDD_DLG_PERSON_INFO };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

private:
    CString m_strPersonName;
    CDateTimeCtrl m_oBirthData;
    INT32 m_dwGender;
    CString m_strNation;
    CString m_strProvince;
    CString m_strIDNumber;
    CString m_strCity;
    CString m_strPicturePath;
    CComboBox   m_oCBoxIDType;

    INT32 m_dwPersonLibID;

    LPNETDEV_PERSON_INFO_S m_pstPersomInfo;

public:
	afx_msg void OnBnClickedBtnBrowse();
    afx_msg void OnBnClickedBtnPersonInfo();
};
