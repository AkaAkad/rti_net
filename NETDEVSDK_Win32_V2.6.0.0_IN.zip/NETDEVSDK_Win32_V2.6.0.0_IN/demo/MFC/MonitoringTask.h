#pragma once
#include "afxcmn.h"
#include "PersonMonitor.h"
#include "VehicleMonitor.h"


// CMonitoringTask �Ի���

class CMonitoringTask : public CDialog
{
	DECLARE_DYNAMIC(CMonitoringTask)

public:
	CMonitoringTask(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMonitoringTask();

// �Ի�������
	enum { IDD = IDD_MONITORING_TASK };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

private:
	void InitCtrl();

    VOID FindPersonMonitor();
    VOID DeletePersonMonitor();

    VOID FindVehicleMonitor();
    VOID DeleteVehicleMonitor();

    std::vector<NETDEV_MONITION_INFO_S> m_oMotitorVector;

public:
	void SetType(INT32 nType);

public:
	CListCtrl m_oMonitoringTaskList;
	INT32 m_nType; //0:��ʾ������1����ʾ����
	CPersonMonitor m_oDlgPersonMonitor;
	CVehicleMonitor m_oDlgVehicleMonitor;

	afx_msg void OnBnClickedBtnAddMonitoringTask();
    afx_msg void OnBnClickedBtnGetMonitoringTask();
    afx_msg void OnBnClickedBtnDelMonitoringTask();
    afx_msg void OnBnClickedBtnModifyMonitoringTask();
};
