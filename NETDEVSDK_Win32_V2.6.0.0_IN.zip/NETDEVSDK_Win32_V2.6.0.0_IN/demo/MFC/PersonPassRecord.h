#pragma once


// CPersonPassRecord �Ի���

class CPersonPassRecord : public CDialog
{
	DECLARE_DYNAMIC(CPersonPassRecord)

public:
	CPersonPassRecord(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPersonPassRecord();

// �Ի�������
	enum { IDD = IDD_PERSON_PASS_RECORD };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
    virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

    BOOL getTimeInfo(INT64& dwBeginTime, INT64& dwEndTime);
    long GetTick(const CString& strTime);
    VOID SavePicture(CString pszFileName, CHAR *pszBuf, INT32 dwSize);
    VOID InitPersonPassList();
    VOID FindPersonPassInfo();
    VOID CleanFaceRecordSnapshotInfoVector();
    VOID DisPlayFaceRecordSnapshotInfoVector();

private:
    CDateTimeCtrl m_oBeginDate;
    CDateTimeCtrl m_oBeginTime;
    CDateTimeCtrl m_oEndDate;
    CDateTimeCtrl m_oEndTime;
    CString m_strAlarmSource;
    CListCtrl m_oPersonInfoPassList;
    CString m_strTotalNumber;
    CString m_strCurrentNumber;

    INT32 m_dwTotalNumber;
    INT32 m_dwCurrentNumber;
    std::vector<NETDEV_FACE_RECORD_SNAPSHOT_INFO_S> m_oFaceRecordSnapshotInfoVector;

public:
    afx_msg void OnBnClickedButton1();
    afx_msg void OnBnClickedButtonPersonPassPrev();
    afx_msg void OnBnClickedButtonPersonPassNext();
};
