#pragma once
#include "afxcmn.h"


// CDlgSelectPro 

class CDlgSelectPro : public CDialog
{
    DECLARE_DYNAMIC(CDlgSelectPro)

public:
    CDlgSelectPro(CWnd* pParent = NULL);
    virtual ~CDlgSelectPro();

    enum { IDD = IDD_DLG_SELECT_PROTOCLO };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);
    virtual BOOL OnInitDialog();
    DECLARE_MESSAGE_MAP()

private:
    void InitListCtrl();
    void InitCombo();

public:
    void handleSimProtocol(LPNETDEV_CUSTON_PROTOCOL_SIMPLE_INFO_S pstDevInfo);

public:
    CListCtrl m_oProtocolSimpleInfoList;
    afx_msg void OnBnClickedGetCustomProList();
    afx_msg void OnBnClickedSetProDetai();
    afx_msg void OnBnClickedProSelected();
    afx_msg void OnBnClickedGetProDetai();
    afx_msg void OnNMClickListDeviceList(NMHDR *pNMHDR, LRESULT *pResult);
    afx_msg void OnClose();

public:

    INT32 m_dwProtocolNum;
    CString m_StrProtocolID;
    CString m_strProName;

    CComboBox m_oAddTransPro;
    INT32 m_udwAddTransPro;
    CString m_StrTransPort;

    CComboBox m_oAddMainStream;
    INT32 m_udwAddMainStream;
    CString m_StrMainStream;

    CComboBox m_oAddSubStream;
    INT32 m_udwAddSubStream;
    CString m_StrSubStream;
    std::vector<NETDEV_CUSTON_PROTOCOL_SIMPLE_INFO_S> m_oProtocolSimpleMap;

};
