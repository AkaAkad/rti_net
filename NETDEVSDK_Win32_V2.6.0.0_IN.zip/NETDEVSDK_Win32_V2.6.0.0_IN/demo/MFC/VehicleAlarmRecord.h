#pragma once


// CVehicleAlarmRecord �Ի���

class CVehicleAlarmRecord : public CDialog
{
	DECLARE_DYNAMIC(CVehicleAlarmRecord)

public:
	CVehicleAlarmRecord(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CVehicleAlarmRecord();
    VOID InitDialog();

// �Ի�������
	enum { IDD = IDD_VEHICLE_ALARM_RECORD };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
    virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

    BOOL getTimeInfo(INT64& dwBeginTime, INT64& dwEndTime);
    long GetTick(const CString& strTime);
    VOID SavePicture(CString pszFileName, CHAR *pszBuf, INT32 dwSize);
    VOID InitVehicleAlarmList();
    VOID FindVehicleAlarmInfo();
    VOID CleanVehicleRecordInfoVector();
    VOID DisPlayVehicleRecordInfoVector();
    CString EnumNETDEV_PLATE_COLOR_EConventToString(INT32 dwEnum);
    CString EnumNETDEV_PLATE_TYPE_EConventToString(INT32 dwEnum);
    CString EnumNETDEV_VEHICLE_TYPE_EConventToString(INT32 dwEnum);
    CString EnumNETDEV_VEHICLE_MONITOR_TYPE_EConventToString(INT32 dwEnum);
private:
    CComboBox m_oCBoxMonitorType;
    CDateTimeCtrl m_oBeginDate;
    CDateTimeCtrl m_oBeginTime;
    CDateTimeCtrl m_oEndDate;
    CDateTimeCtrl m_oEndTime;
    CString m_strBayonetName;
    CString m_strPlateNumber;
    CComboBox m_oCBoxPlateColor;
    CComboBox m_oCBoxCarColor;
    CComboBox m_oCBoxMonitorReason;
    CListCtrl m_oVehicleAlarmList;
    CString m_strTotalNumber;
    CString m_strCurrentNumber;

    INT32 m_dwTotalNumber;
    INT32 m_dwCurrentNumber;
    std::vector<NETDEV_VEHICLE_RECORD_INFO_S> m_oVehicleRecordInfoVector;

public:
    afx_msg void OnBnClickedButtonVehicleAlarmFind();
    afx_msg void OnBnClickedButtonVehicleAlarmPrev();
    afx_msg void OnBnClickedButtonVehicleAlarmNext();
};
